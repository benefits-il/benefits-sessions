# חמשת הרעיונות — פרומפטים מוכנים

בחרו רעיון אחד. כל אחד בונה תוצר אחר של NotebookLM — מצגת, חידון, כרטיסיות, טבלת נתונים ומפת ידע — ומלמד גם משהו טכני אחר. מדביקים את הפרומפט של הרעיון שבחרתם בקלוד, וקלוד בונה את כל השרשרת בעצמו: יוצר מחברת, כותב מקור, מפיק artifact, מוריד אותו, ובונה ממנו עמוד אינטראקטיבי שנפתח בדפדפן.

לכל רעיון יש את הפרומפט בעברית ואת אותו הפרומפט באנגלית — השתמשו בזה שמתאים לכם.

---

## רעיון 1 — חידון אינטראקטיבי (artifact: quiz)

```
אתה מחובר ל-NotebookLM דרך MCP. בצע את כל השלבים בעצמך, אחד אחרי השני, בלי לעצור לשאול:

1. צור מחברת חדשה ב-NotebookLM בשם "חידון מערכת השמש".
2. כתוב בעצמך מסמך מקור בעברית, עשיר וברור, על מערכת השמש (השמש, שמונת כוכבי הלכת, הירח, ועובדות מעניינות). הוסף אותו כמקור טקסט למחברת וחכה שהעיבוד יסתיים.
3. צור artifact מסוג חידון (quiz): 10 שאלות, עברית, רמת קושי קלה. בדוק סטטוס עד שהחידון מוכן.
4. הורד את החידון כקובץ JSON.
5. בנה עמוד HTML יחיד ואינטראקטיבי מהחידון, שמור אותו ופתח בדפדפן:
   - עברית, RTL, פונט Rubik, עיצוב חלל כהה עם כוכבים.
   - שאלה אחת בכל פעם, 4 תשובות, פס התקדמות וניקוד.
   - ערבב את סדר התשובות (ב-JSON התשובה הנכונה תמיד ראשונה - אסור שתופיע תמיד ראשונה).
   - בלחיצה על תשובה: ירוק לנכונה, אדום לשגויה, והצג את ההסבר (rationale) של הנכונה.
   - כפתור "רמז" (מציג hint), כפתור "הבא", ובסוף מסך ניקוד עם "שחק שוב".
   - הטמע את ה-JSON בתוך ה-HTML (פתיחה מ-file:// חוסמת fetch לקבצים מקומיים). אם יש בטקסט סימוני נוסחה כמו \frac{2}{3} - נקה לטקסט רגיל.

בסיום, אמור לי איפה שמרת את הקובץ.
```

או, אותו פרומפט באנגלית:

```
You are connected to NotebookLM through MCP. Perform all the steps yourself, one after another, without stopping to ask:

1. Create a new notebook in NotebookLM named "Solar System Quiz".
2. Write a source document yourself, rich and clear, about the solar system (the Sun, the eight planets, the Moon, and interesting facts). Add it as a text source to the notebook and wait for processing to finish.
3. Create a quiz artifact: 10 questions, easy difficulty. Check the status until the quiz is ready.
4. Download the quiz as a JSON file.
5. Build a single interactive HTML page from the quiz, save it and open it in the browser:
   - Rubik font, a dark space design with stars.
   - One question at a time, 4 answers, a progress bar and a score.
   - Shuffle the answer order (in the JSON the correct answer is always first - it must not always appear first).
   - On clicking an answer: green for correct, red for wrong, and show the rationale of the correct one.
   - A "hint" button (shows the hint), a "next" button, and at the end a score screen with "play again".
   - Embed the JSON inside the HTML (opening from file:// blocks fetch of local files). If the text contains formula markup like \frac{2}{3} - clean it to plain text.

When done, tell me where you saved the file.
```

---

## רעיון 2 — מסלול טיול (artifact: slide deck)

```
אתה מחובר ל-NotebookLM דרך MCP. בצע את כל השלבים בעצמך, אחד אחרי השני, בלי לעצור לשאול:

1. צור מחברת חדשה ב-NotebookLM בשם "טיול ברומא - 48 שעות".
2. כתוב בעצמך מדריך טיול בעברית לרומא: שמונה אתרים מומלצים, ולכל אתר משפט טיפ קצר ושעה מומלצת לביקור. הוסף אותו כמקור טקסט וחכה שהעיבוד יסתיים.
3. צור artifact מסוג מצגת (slide deck) בפורמט presenter_slides, בעברית, עם הנחיה: שקף נפרד לכל אתר, ובכל שקף תמונה יפהפייה ומציאותית של האתר ובמרכז שם האתר בעברית בלבד, בלי טקסט נוסף. בדוק סטטוס עד שהמצגת מוכנה (זה לוקח כמה דקות כי יש תמונות).
4. הורד את המצגת כ-PDF.
5. חלץ כל עמוד ב-PDF לתמונת PNG נפרדת (השתמש בכלי כמו pdftoppm או כל כלי PDF-לתמונה זמין, והתקן אם צריך).
6. בנה עמוד HTML יחיד ואינטראקטיבי, שמור ופתח בדפדפן:
   - עברית, RTL, פונט Rubik, אווירה חמה (גווני טרקוטה).
   - גריד של כרטיסי יעדים, כרטיס לכל אתר עם התמונה שלו והשם.
   - בלחיצה על כרטיס הוא מתהפך/נפתח וחושף את הטיפ והשעה המומלצת (מתוך המקור שכתבת).
   - התעלם משקף השער ושקף הסיום אם יש, או הצג אותם כ-hero ופוטר.

בסיום, אמור לי איפה שמרת את הקובץ.
```

או, אותו פרומפט באנגלית:

```
You are connected to NotebookLM through MCP. Perform all the steps yourself, one after another, without stopping to ask:

1. Create a new notebook in NotebookLM named "Rome Trip - 48 Hours".
2. Write a travel guide to Rome yourself: eight recommended sites, and for each a short tip sentence and a recommended hour to visit. Add it as a text source and wait for processing to finish.
3. Create a slide deck artifact in presenter_slides format, with the instruction: a separate slide for each site, and on each slide a beautiful, realistic image of the site with the site's name in the center and no other text. Check the status until the deck is ready (this takes a few minutes because of the images).
4. Download the deck as a PDF.
5. Extract each page of the PDF to a separate PNG image (use a tool like pdftoppm or any available PDF-to-image tool, and install one if needed).
6. Build a single interactive HTML page, save it and open it in the browser:
   - Rubik font, a warm atmosphere (terracotta tones).
   - A grid of destination cards, one card per site with its image and name.
   - On clicking a card it flips/opens and reveals the tip and the recommended hour (from the source you wrote).
   - Ignore the title slide and the closing slide if there are any, or show them as a hero and a footer.

When done, tell me where you saved the file.
```

---

## רעיון 3 — כרטיסיות שפה (artifact: flashcards)

```
אתה מחובר ל-NotebookLM דרך MCP. בצע את כל השלבים בעצמך, אחד אחרי השני, בלי לעצור לשאול:

1. צור מחברת חדשה ב-NotebookLM בשם "איטלקית לטיול".
2. כתוב בעצמך רשימה בעברית של כ-30 מילים וביטויים שימושיים לטיול, כל אחד עם התרגום לאיטלקית. הוסף אותה כמקור טקסט וחכה שהעיבוד יסתיים.
3. צור artifact מסוג כרטיסיות (flashcards), בעברית. בדוק סטטוס עד שהן מוכנות.
4. הורד את הכרטיסיות כקובץ JSON.
5. בנה עמוד HTML יחיד ואינטראקטיבי, שמור ופתח בדפדפן:
   - עברית, RTL, פונט Rubik, נגיעת צבע של דגל איטליה (ירוק-לבן-אדום).
   - כרטיס אחד בכל פעם. בלחיצה הכרטיס מתהפך באנימציית 3D: עברית בצד אחד, איטלקית בצד השני.
   - כפתורים: הקודם, הבא, וערבב. מונה "כרטיס X מתוך N".
   - הטמע את ה-JSON בתוך ה-HTML (פתיחה מ-file:// חוסמת fetch לקבצים מקומיים).
   - שים לב: המונה בעברית RTL - נסח אותו במילים ("כרטיס X מתוך N") כדי שלא יתהפך.

בסיום, אמור לי איפה שמרת את הקובץ.
```

או, אותו פרומפט באנגלית:

```
You are connected to NotebookLM through MCP. Perform all the steps yourself, one after another, without stopping to ask:

1. Create a new notebook in NotebookLM named "Italian for Travel".
2. Write a list yourself of about 30 useful travel words and phrases, each with its Italian translation. Add it as a text source and wait for processing to finish.
3. Create a flashcards artifact. Check the status until they are ready.
4. Download the flashcards as a JSON file.
5. Build a single interactive HTML page, save it and open it in the browser:
   - Rubik font, a touch of the Italian flag colors (green-white-red).
   - One card at a time. On clicking, the card flips with a 3D animation: English on one side, Italian on the other.
   - Buttons: previous, next, and shuffle. A "card X of N" counter.
   - Embed the JSON inside the HTML (opening from file:// blocks fetch of local files).

When done, tell me where you saved the file.
```

---

## רעיון 4 — טבלת השוואה (artifact: data table)

```
אתה מחובר ל-NotebookLM דרך MCP. בצע את כל השלבים בעצמך, אחד אחרי השני, בלי לעצור לשאול:

1. צור מחברת חדשה ב-NotebookLM בשם "השוואת כלי AI".
2. כתוב בעצמך מסמך בעברית שמשווה שמונה כלי בינה מלאכותית. לכל כלי: שם, שימוש עיקרי, חוזק בולט, מודל תמחור, ולמי מתאים. הוסף אותו כמקור טקסט וחכה שהעיבוד יסתיים.
3. צור artifact מסוג טבלת נתונים (data table) עם תיאור העמודות. בדוק סטטוס עד שהיא מוכנה.
4. שים לב ל-limitation אמיתי: טבלת נתונים אינה ניתנת להורדה אוטומטית דרך ה-MCP. לכן בנה את הטבלה בעמוד מתוך הנתונים שכתבת במקור בשלב 2 (יש לך אותם).
5. בנה עמוד HTML יחיד ואינטראקטיבי, שמור ופתח בדפדפן:
   - עברית, RTL, פונט Rubik, עיצוב מקצועי בהיר עם אקסנט כחול.
   - טבלה עם העמודות, ותג צבעוני לתמחור (חינמי = ירוק, חינמי+מנוי = כחול, בתשלום = כתום).
   - לחיצה על כותרת עמודה ממיינת לפיה. שדה חיפוש שמסנן. לחיצה על שורה פותחת פרטים ("למי מתאים").

בסיום, אמור לי איפה שמרת את הקובץ.
```

או, אותו פרומפט באנגלית:

```
You are connected to NotebookLM through MCP. Perform all the steps yourself, one after another, without stopping to ask:

1. Create a new notebook in NotebookLM named "AI Tools Comparison".
2. Write a document yourself comparing eight AI tools. For each tool: name, main use, standout strength, pricing model, and who it suits. Add it as a text source and wait for processing to finish.
3. Create a data table artifact with a description of the columns. Check the status until it is ready.
4. Note a real limitation: a data table cannot be downloaded automatically through the MCP. So build the table in the page from the data you wrote in the source in step 2 (you have it).
5. Build a single interactive HTML page, save it and open it in the browser:
   - Rubik font, a clean, light, professional design with a blue accent.
   - A table with the columns, and a colored tag for pricing (free = green, free + subscription = blue, paid = orange).
   - Clicking a column header sorts by it. A search field that filters. Clicking a row opens details ("who it suits").

When done, tell me where you saved the file.
```

---

## רעיון 5 — מפת ידע (artifact: mind map)

```
אתה מחובר ל-NotebookLM דרך MCP. בצע את כל השלבים בעצמך, אחד אחרי השני, בלי לעצור לשאול:

1. צור מחברת חדשה ב-NotebookLM בשם "מפת ידע - בינה מלאכותית".
2. כתוב בעצמך סקירה היררכית בעברית על עולם ה-AI, עם ענפים ברורים (לדוגמה: סוגי מודלים, שימושים עיקריים, מושגי יסוד, אתגרים, ומגמות עתידיות), ובכל ענף כמה תתי-נושאים. הוסף אותה כמקור טקסט וחכה שהעיבוד יסתיים.
3. צור artifact מסוג מפת חשיבה (mind map) עם כותרת מתאימה. שים לב: ה-JSON של המפה חוזר מיד בתשובה, אין צורך להמתין או להוריד קובץ.
4. השתמש ב-JSON של המפה (מבנה של name ו-children).
5. בנה עמוד HTML יחיד ואינטראקטיבי, שמור ופתח בדפדפן:
   - עברית, RTL, פונט Rubik, אקסנט סגול.
   - עץ ידע: הענף הראשי פתוח, ובלחיצה על ענף הוא נפתח/נסגר ומציג את תתי-הנושאים שלו, עם מספר הילדים בכל ענף.
   - הטמע את נתוני המפה בתוך ה-HTML.

בסיום, אמור לי איפה שמרת את הקובץ.
```

או, אותו פרומפט באנגלית:

```
You are connected to NotebookLM through MCP. Perform all the steps yourself, one after another, without stopping to ask:

1. Create a new notebook in NotebookLM named "Knowledge Map - Artificial Intelligence".
2. Write a hierarchical overview yourself about the world of AI, with clear branches (for example: types of models, main uses, core concepts, challenges, and future trends), and under each branch a few sub-topics. Add it as a text source and wait for processing to finish.
3. Create a mind map artifact with a suitable title. Note: the map's JSON comes back immediately in the response, there is no need to wait or download a file.
4. Use the map's JSON (a structure of name and children).
5. Build a single interactive HTML page, save it and open it in the browser:
   - Rubik font, a purple accent.
   - A knowledge tree: the main branch open, and on clicking a branch it opens/closes and shows its sub-topics, with the number of children on each branch.
   - Embed the map data inside the HTML.

When done, tell me where you saved the file.
```
