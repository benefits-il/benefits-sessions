# Plan 7 — Expand & Deploy (go all the way)

**Goal:** take the full Toki running on your machine and finish it — a Telegram bot so you can
send a link from your phone, support for cookie-gated platforms, and cloud hosting so it runs
even when your computer is off.

**Do this after the full system works locally** (plan 6, stage 2). Add one layer at a time and
test after each. You do not have to finish all of it in class — starting is the point; each layer
stands on its own and you can continue at home.

---

## Layer 1 — the Telegram bot

Send a link to a bot from your phone; it processes it and replies with the result.

**Manual part first** (plan 1): get `TELEGRAM_BOT_TOKEN` from @BotFather and your numeric id from
@userinfobot for `ALLOWED_USER_IDS`.

```
Add a Telegram bot (python-telegram-bot) that wraps the existing flow.

- On /start: a short bilingual welcome (Hebrew + English).
- On any text message: scan it for video links. For each link found, run the SAME process_url as
  the CLI (plan 6) — reuse it, don't rewrite the flow.
- Reply with live status, editing one message through the stages: "⏳ Processing..." →
  "📥 Downloading..." → "📖 Reading..." → "🧠 Analyzing..." → "📤 Saving...". On success,
  reply with the note's title, its category (with emoji), relevance as stars, and the dashboard
  deep-link. On failure, reply "❌" with a short error.
- SECURITY: gate every update against ALLOWED_USER_IDS (comma-separated). If the list is empty,
  refuse everyone and log the caller's id, so you can copy your own id into .env and restart.
  This is how a personal bot stays personal.
- DE-DUP: track seen update ids and drop repeats, so a redelivered update never runs twice.
- ONE POLLING INSTANCE PER BOT TOKEN: a Telegram bot token allows exactly one poller. If a local
  instance is still running when a second one starts (or when the cloud one goes live), Telegram
  returns 409 Conflict. Stop the local bot before the cloud bot goes up.

Explain what you understood and wait for approval before you build.
```

**Test:** `python bot.py`, send it a link from your phone, watch the status message walk through
the stages, and confirm the note lands in your repo and the dashboard updates.

---

## Layer 2 — cookie-gated platforms

Most short-video sites download without login. Some (e.g. Instagram) need a logged-in browser
profile. The downloader (plan 3) already reads `COOKIES_FROM_BROWSER` and passes
`--cookies-from-browser` to yt-dlp at run time, so locally this already works — **use Firefox.**
Chrome and Edge cannot be read (since Chrome 127 they encrypt their cookie store in a way yt-dlp
cannot open), so they are not an option.

**The cloud catch:** a cookie read from a browser profile is a **personal login credential**, and a
cloud server has no browser profile at all. Shipping that credential to a server is exactly what you
do not want to do. So a cookie-gated platform is **local-only**, and the cloud build should refuse
it fast rather than fail deep in a download:

```
Add a cloud-awareness flag and a fail-fast guard to the downloader.
- config.is_cloud(): true when a cloud-provided environment variable is present (the platform sets
  one automatically) OR when CLOUD=1 is set — so you can simulate cloud behaviour locally.
- When is_cloud() is true and the link is a cookie-gated platform (e.g. Instagram), STOP
  immediately with a clear instruction to run that link locally — do NOT attempt the download, and
  never ship a browser cookie to the server.
- Leave COOKIES_FROM_BROWSER EMPTY in the cloud (there is no browser there).

Explain what you understood and wait for approval before you build.
```

> Cookies expire when you log out or after a while — the runtime read from Firefox picks up the
> current session automatically, so just stay logged in.

---

## Layer 3 — run in the cloud (Railway)

So far the bot runs only while your machine is on. This layer deploys it to run continuously.

**Manual part first** (plan 1): sign up at railway.app.

```
Prepare the bot for cloud deployment on Railway.
- Add a Dockerfile (python:3.11-slim + ffmpeg installed via apt, pip install -r requirements.txt,
  CMD runs the bot) and a railway.toml (builder = DOCKERFILE, restart on failure). ffmpeg is
  installed for `ffprobe` ONLY — the downloader uses it to confirm a video stream exists; nothing
  in this tool re-encodes or extracts audio.
- Before the first deploy, VERIFY requirements.txt against the actual imports: every package the
  code imports must be listed. A package you pip-installed locally but forgot to add crashes only
  inside the container, never on your machine.
- Make sure .env, .work/, output/, and __pycache__ are in .gitignore AND .dockerignore — the
  secrets and temp files must never ship.
- Give me an exact Railway checklist: connect the repo, paste EVERY environment variable that
  `.env.example` marks as required, LEAVE the cloud-empty ones empty (e.g. COOKIES_FROM_BROWSER —
  there is no browser in the cloud), deploy, and watch the logs until the bot reports it is running.

Explain what you understood and wait for approval before you build.
```

**Verify end to end:**
1. Railway logs show the bot started and connected.
2. Send the bot a real link from your phone.
3. Confirm the note appears in your GitHub repo and the dashboard updates on its own.

Now Toki runs on its own, in the cloud, on your accounts only. That is the finished tool — the
full thing, yours.

---

## Six principles for deploying a personal tool

These came out of the live run's move from a working local tool to a running cloud one. Each is a
general rule, not a Toki quirk — they apply to almost any personal tool you push to a server.

1. **Split the artifact repo from the code repo the platform deploys from.** Toki writes its notes
   into a GitHub repo and the platform redeploys on every push to the repo it watches. If those are
   the **same** repo, every note the tool saves triggers a redeploy. Keep the code the server runs
   and the data the tool produces in **separate** repos.
2. **Treat `.env.example` as the deployment manifest.** It lists every variable the tool needs and
   marks which must stay **EMPTY** in the cloud (a browser-cookie var has no meaning on a server).
   Deploy by walking that file top to bottom — it is the single source of truth for what the server
   needs and what it must not carry.
3. **Add a cloud-awareness flag and a fail-fast guard for anything physically impossible in the
   cloud.** A capability that needs a local login cookie cannot work on a server. Detect the cloud
   and **refuse instantly with an instruction** ("run this one locally") rather than attempting it —
   and never ship a personal session credential to a server to make it work. (This is Layer 2.)
4. **Exactly one polling instance per bot token.** A Telegram bot token allows one poller. Stop the
   local bot before the cloud one goes live, or Telegram returns 409 Conflict and neither works
   reliably.
5. **Verify the dependency manifest against the actual imports before the first deploy.** A package
   you pip-installed locally but never added to `requirements.txt` runs fine on your machine and
   crashes only inside the container. Check every import is listed before you push.
6. **Test a deploy credential functionally, and scope it to the minimum.** Before trusting a token,
   actually use it against the target (make it write to the one repo it is for). Scope it to that
   single repo with only the permissions it needs — nothing broader. Never ship a wide account
   token that can touch everything you own.

---

## Troubleshooting

- **The bot crashes on deploy** → a missing environment variable in Railway. Read the logs, add
  it, and Redeploy (Railway doesn't always pick up changes automatically — redeploy manually).
- **The bot doesn't answer you** → your id isn't in `ALLOWED_USER_IDS`, or the list is empty and
  it's refusing everyone. Check the logs for the caller id it printed, and add it.
- **A gated platform still fails** → `COOKIES_FROM_BROWSER` is unset or points at Chrome/Edge (use
  Firefox), or you are logged out of that platform in Firefox — log back in. In the cloud, a
  cookie-gated platform is refused by design; run it locally.
- **The bot answers 409 / two instances fight** → a local poller is still running against the same
  token. One poller per bot token; stop the local one.
- **`.env` got committed** → rotate every key in it immediately (they're burned), then fix
  `.gitignore` and remove the file from history.
