# Plan 2 — Discover Your Categories (the first soul)

**Goal:** decide the four-to-six personal categories that Toki files every note under. This is
the personalization at the heart of the tool — the processor (plan 4) classifies into these
categories, and the dashboard (plan 5) is organized by them. Do this **before** you build the
processor: the categories are an input to its brain, not an afterthought.

**Why this is a soul:** without your own categories, Toki is a generic transcriber. With them,
it is a mirror of what you actually follow — every note lands in a bucket that means something
to *you*. Spend real thought here.

---

## The two ways to discover them

Pick whichever fits. Both end with the same thing: a config block you paste into the build.

### Option A — let Claude read its memory of you

If you've been chatting with Claude on the web, it can propose categories from what it already
knows about your work and interests. Paste this into a conversation on claude.ai and bring back
the result:

```
You're helping me set up a personal knowledge system that processes short tech videos and
organizes the insights by topic.

The system classifies every video into one of MY personal interest categories. Help me figure
out what those categories should be.

Based on what you know about me from our past conversations (my work, projects, interests, tech
stack, learning goals), identify 4-6 meaningful categories that represent the areas I actively
care about. If you don't have enough context, interview me with these questions:
1. What are you working on right now? (projects, job, side projects)
2. What tech stack do you use daily?
3. What topics do you actively seek out in tech content?
4. Are there specific people, companies, or communities whose content you follow?
5. What are you trying to learn or improve at in the next 3-6 months?

Once you understand my interests, output EXACTLY this format:

CATEGORIES = {
    "category-slug": {
        "he": "שם בעברית",
        "en": "English Name",
        "desc": "Detailed description of what belongs in this category. Be specific — list
                 concrete topics, tools, frameworks, use cases. 2-3 sentences.",
    },
    # ... 4-6 total
    "other": {
        "he": "אחר",
        "en": "Other",
        "desc": "Content that doesn't clearly fit any category above.",
    },
}

CATEGORY_EMOJIS = { "category-slug": "🧠", "other": "📦" }        # one emoji per category
CATEGORY_ICONS  = { "category-slug": "brain", "other": "package" } # one Lucide icon name each
CATEGORY_COLORS = { "category-slug": "#8B5CF6", "other": "#64748B" } # one accent color each

Rules:
- Slugs are lowercase-kebab-case (e.g. "machine-learning", "web-dev").
- Hebrew names are natural and short (1-3 words).
- Descriptions are specific enough for an AI to classify a transcript into the right category.
- Always include "other" as the last category.
- Icons are valid Lucide icon names (lucide.dev/icons); colors are vibrant and distinct.

Think step by step about what I actually care about, then generate the config.
```

### Option B — build them with Claude Code right here

Prefer to do it in the build window? Answer these five questions and have Claude Code generate
the same config block from your answers:

1. What are you working on right now? (projects, job, side projects)
2. What tech stack do you use daily?
3. What topics do you actively seek out in tech content?
4. Are there specific people, companies, or communities whose content you follow?
5. What are you trying to learn or improve at in the next 3-6 months?

---

## What "done" looks like

- You have a `CATEGORIES` block with 4-6 real categories plus `"other"`, each with a Hebrew
  name, an English name, and a **specific** description — plus an emoji, a Lucide icon name, and
  an accent color per category.
- The slugs are lowercase-kebab-case and will become the folder names in your repo and the
  filter pills on the dashboard.
- The descriptions are concrete enough that, reading a transcript, you could sort it yourself —
  because that is exactly the judgment the processor will make from them.

## Notes for the build

- Keep this config in one place — it is imported by the processor (plan 4), the formatter and
  storage (plan 5), and the dashboard (plan 5). One source of truth for categories.
- Categories aren't frozen. When a note keeps landing in "other", that's a signal to add a
  category. Edit the config and rebuild the index; new notes classify against the new set.
- Save the finished config into the studio's `Design/` subfolder (e.g. `categories.md`) so the
  oven can find it later — it is the first of the two design decisions the oven tracks.
