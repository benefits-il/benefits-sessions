# Toki — Build Plans Overview

These are the **execution plans** for building Toki. The oven (`oven.md`) and the world
document (`toki.md`) are the *thinking* — in Hebrew, for you to understand what you are
building. These plans are the *doing* — detailed, step-by-step, in English, written so a
fresh Claude Code window can execute them with zero prior context.

> STUDIO road rule: **think in one window, build in another.** You read and plan here;
> each plan runs in its own clean Claude Code window. The oven hands you the right plan at
> the right step and waits for you between them.

## What you are building — the real thing

Toki is a private system that turns a link to a short video into an accurate, structured
Hebrew knowledge note — classified by **your own** interest categories, enriched, fact-checked,
and saved to a searchable archive you own. It is **not a dumb transcriber.** The flow is a
straight chain, but a smart brain sits in the middle of it:

```
video link (Reels, Shorts, and other short-video sites yt-dlp supports)
  → DOWNLOAD        (yt-dlp pulls the VIDEO; some platforms need a logged-in Firefox profile)
  → READ            (Gemini, multimodal: spoken words AND on-screen text, source language)
  → PROCESSOR       — the BRAIN: classify into ONE of your categories, rate relevance,
                      translate to Hebrew, extract tools/repos/actions, verify claims   ← the deliverable
  → FORMAT          (Markdown + frontmatter, filed under the category)
  → STORE           (GitHub repo + auto-generated README index)
  → DISPLAY         (a searchable HTML dashboard on GitHub Pages)
```

> **The chain reads the video, not just its audio.** A large share of short tech videos have **no
> speech at all** — every tool name and URL lives only as text on screen. An audio-only chain
> would return nothing for those and delete them silently as "music only". So Toki keeps the video
> and reads **two channels** (speech + on-screen text); either one alone is enough to make a note.
> This is the read-the-video architecture the live run proved. (Details in plan 03.)

Above the chain sits a **one-time discovery step**: before you build, you discover **what you
care about** — four to six personal categories. That discovery feeds the processor (it
classifies into your categories) and the dashboard. It is set up once, not a gate on every run.

You are **reconstructing this from the plans — not cloning finished code.** Claude Code writes
the code, guided by each plan; you drive.

## The two souls — do not water these down

1. **Personal classification — the note is filed under YOUR mind's map, not a generic one.**
   Every video is classified into one of the categories you discovered up front, and **every tool
   inside the note carries its own category too** — because a "5 useful sites" video routinely
   spans four categories at once. Without this, Toki is a generic transcriber; with it, Toki is a
   mirror of what you actually follow. (Plan 02 discovers the categories; the processor in plan 04
   classifies by them, twice.)
2. **The processor extracts and verifies — it never just transcribes.** It reorganizes the reading
   (speech + on-screen text) into a structured Hebrew note: one category, a relevance score, a
   summary, key insights, a tools table (with real, web-verified URLs), repos, action items — and
   it flags dubious claims. Extraction plus skepticism, not a text dump. (Plan 04.)

If either of these is missing, you have a toy, not Toki.

## The build order

| # | Plan | What it builds | When |
|---|---|---|---|
| 1 | `01-signups-and-keys.md` | Every account + API key in one table | Before anything runs |
| 2 | `02-discover-categories.md` | Your personal categories — the classification map | Before the processor |
| 3 | `03-download-and-read.md` | Video download + speech **and on-screen text** | Trial run |
| 4 | `04-processor-agent.md` | The processor — the deliverable's brain | Trial run |
| 5 | `05-store-and-dashboard.md` | GitHub storage, README index, HTML dashboard | Full system |
| 6 | `06-build-the-app.md` | Wire it all into the CLI | **PLAN MODE** |
| 7 | `07-expand-and-deploy.md` | Telegram bot, cloud deploy, cookie-gated sites | Go all the way |

**Execution order (the file numbers are topics, not a strict run order):**

1. Discover the categories (plan 2) — you need them before the processor.
2. Build the two units — download + read (plan 3) and the processor (plan 4) — and unit-test each
   locally.
3. Run **plan 6, Stage 1** — the thin slice: wire the units into a CLI and prove a link flows
   end to end with **local file** output, on one category set. No GitHub, no dashboard yet.
4. Only now do the heavy part — **plan 5** (GitHub storage, README index, the HTML dashboard).
5. Run **plan 6, Stage 2** — grow to the full system (GitHub-backed storage + dashboard,
   batch mode).
6. **Plan 7** — the Telegram bot, cloud deploy, and cookie-gated platforms.

This is the golden rule in action: **the thin local slice runs before you build GitHub, the
dashboard, or the bot.** **The destination is the full Toki, not the thin slice.** You do not
have to finish it all in class — starting is the point; the rest can continue at home.

## The two golden rules of this build

1. **Environment variables first.** Every part of Toki is driven by keys in a `.env` file.
   One empty value = a crash. Fill the whole table in plan 1 before you build.
2. **Lean end-to-end before wide.** Prove the thin slice before you add breadth. Do not build
   GitHub, the dashboard, batch mode, or the bot until a link flows all the way through to a
   local note.

## The Gemini standard

**Both model calls in Toki run on Gemini** — one engine, one key: the reader and the processor.
(In the original, reading and processing ran on separate providers; here both run on Gemini. If
you later want to upgrade just the processor to a stronger model, that is a home upgrade after the
tool works — not part of this build.)

**The models (what the live run settled on):** both the reader and the processor run on
`gemini-3.5-flash`. The live run confirmed it reads on-screen text reliably at a low token cost
for a short clip. Do **not** use `gemini-2.5-pro` — it returns 404 for newly created API keys.
Model ids move over time; if one 404s, check the current list in AI Studio and swap it. Both are
overridable via `READER_MODEL` and `PROCESSOR_MODEL` in `.env`.

> **Locked decision — do not "fix" this.** Toki calls the Gemini API **directly**, on purpose.
> It does not route through the course's gemini-engine (the Unit-1 asset that Pixi rides on):
> Toki is a self-contained private tool with its own key, and the direct call is what keeps it
> that way. A future build pass should keep the direct call — this is deliberate, not an oversight.
