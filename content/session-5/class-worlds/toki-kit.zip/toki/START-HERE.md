# מכאן מתחילים — ערכת טוקי

בתיקייה הזאת יש שני קבצים שחשובים לך:

- `oven.md` — התנור: שיטת STUDIO והמצב החי של הפרויקט.
- `toki.md` — מסמך העולם: כל מה שידוע על טוקי, כבר ממופה.

**מה עושים:** פותחים את התיקייה הזאת בקלוד קוד, ומדביקים את הפרומפט הבא.

---

```
בתיקייה הזאת יש שני קבצים: oven.md ("התנור") ו-toki.md (מסמך העולם).

קרא קודם את oven.md — הוא מסביר את שיטת STUDIO ואיך עובדים איתה, והוא ההוראות שלך.
אחר כך קרא את toki.md — הוא מכיל את כל מה שכבר ידוע על הפרויקט שאני בונה, טוקי:
מערכת שמקבלת לינק לסרטון קצר ומחזירה פתק-ידע מובנה בעברית — מורידה את הסרטון, קוראת
אותו (גם דיבור וגם טקסט על המסך), ואז מסווגת לפי הקטגוריות שלי, מתרגמת, מחלצת כלים
וקישורים, ומאמתת אותם מול הרשת. הכל נשמר אצלי בארכיון ניתן-לחיפוש. חילוץ ואימות, לא תמלול.

אחרי שקראת את שניהם:
1. צור את תת-התיקיות של הסטודיו: Scout, Target, Unify, Design, Index, Operate —
   ורשום ב"מפת התיקייה" שבתנור מה תפקיד כל אחת.
2. מלא את התנור ממסמך העולם: העבר לתוך משבצות התחנות שבתנור את מה שכבר ידוע מ-toki.md.
3. אמור לי איפה הפרויקט עומד: מה כבר מלא, מה חסר, ומה הצעד הבא. רוב הדברים כאן כבר
   סגורים — מה שבאמת פתוח לדיוק הוא שתי הנשמות (תחנה 4): הקטגוריות האישיות שלי, וזהות
   הפתק שיוצא מהמוח.

מכאן והלאה אתה המלווה של הפרויקט: בכל פעם שאני חוזר, קרא קודם את התנור, אמור לי איפה
אנחנו, והוֹבל אותי לשלב הבא — קודם לגלות איתי את הקטגוריות, ואז להפקה לפי התוכניות
המפורטות שבתיקיית plans/. מסוֹר לי תוכנית אחת בכל פעם, לפי הסדר, וחכה לי ביניהן. אחרי
כל עבודה — עדכן את התנור.

תסביר מה הבנת ותחכה לאישור כדי להמשיך.
```

או, אותו פרומפט באנגלית:

```
This folder has two files: oven.md ("the oven") and toki.md (the world document).

Read oven.md first — it explains the STUDIO method and how to work with it, and it is
your instructions. Then read toki.md — it holds everything already known about the project
I am building, Toki: a system that takes a link to a short video and returns a structured
Hebrew knowledge note — it downloads the video, reads it (both the spoken words and the
on-screen text), then classifies it by my own categories, translates it, extracts the tools
and links it mentions, and verifies them against the web. Everything is saved to my own
searchable archive. Extraction and verification, not transcription.

After you have read both:
1. Create the studio subfolders: Scout, Target, Unify, Design, Index, Operate — and record
   in the "folder map" in the oven what each one is for.
2. Fill the oven from the world document: move what is already known from toki.md into the
   station slots in the oven.
3. Tell me where the project stands: what is already filled, what is missing, and what the
   next step is. Most things here are already settled — what is genuinely open for
   refinement is the two souls (station 4): my personal categories, and the identity of the
   note the brain produces.

From here on you are the project's companion: every time I come back, read the oven first,
tell me where we are, and lead me to the next step — first to discover the categories with
me, then to production per the detailed plans in the plans/ folder. Hand me one plan at a
time, in order, and wait for me between them. After every piece of work — update the oven.

Explain what you understood and wait for approval to continue.
```
