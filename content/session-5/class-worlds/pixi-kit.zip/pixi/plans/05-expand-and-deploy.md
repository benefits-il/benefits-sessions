# Plan 05 — Expand & Deploy (run it with the PC off)

**Goal:** take the bot that works locally (plan 04) and deploy it to **Railway** so the whole
chain runs 24/7 in the cloud — a one-line idea from your phone comes back as a finished video with
your computer off.

**Do this after the bot works locally** (plan 04, including the $0 dry-run rehearsal). The local
mode still works exactly as before; this layer packs the same code into one Docker image so it
also runs in the cloud. You do not have to finish it in class — starting is the point; it stands
on its own and you can continue at home.

---

## Deploy keys (Pixi has no signups plan — collect these here)

Pixi builds its engine and identity in class, so it has no separate signups plan; this plan
carries its own deploy keys. **Two handling rules — keep these the whole way:**

- **A key goes into your terminal, your `.env` file, or a Railway variable — never in the chat.**
  Don't paste a token or key into the conversation, a prompt, or any message. If one ever lands in
  a chat, treat it as burned: go back to its source and **rotate it** (issue a new one, revoke the
  old). Pasted it in chat ← rotate.
- **Placeholders include their brackets.** Wherever this plan writes `<...>`, replace the **whole**
  thing — the angle brackets too, every occurrence.

| Variable | Where to get it | Needed for |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | @BotFather (you already have it from plan 04) | The bot |
| `OWNER_CHAT_ID` | the bot printed it on `/start` (plan 04) | Single-user guard |
| `GEMINI_API_KEY` | copied from the engine's own `.env` | The engine reaches media |
| Railway account | railway.app — sign up (you can use GitHub) | The cloud host |

Every one of these is set **as a Railway variable only** — never baked into the Docker image,
never committed to the repo, never shown in chat. The **`GEMINI_API_KEY` is the same key** from
Unit 1; it is copied from the engine's `.env` into a Railway variable so the vendored engine can
read it from the environment when there is no `.env` file in the container. It is not a new key,
and it is never requested in chat.

---

## Layer 1 — one Docker image, deployed to Railway

The cloud build packs everything the chain needs into **one Docker image**: the bot + the engine
(vendored) + the browser rendering the code layers + ffmpeg + the brand assets.

```
Prepare the bot for cloud deployment on Railway in one Docker image.
- Base the image on one that already ships a headless browser (for the code brand layers) and
  add ffmpeg. VENDOR the engine into the deploy folder (e.g. deploy/engine/server.py) so the
  image is self-contained; the vendored engine reads GEMINI_API_KEY from the environment when no
  .env file is present — same engine, same single-wrapper rule, no direct API call.
- Secrets are Railway variables ONLY (TELEGRAM_BOT_TOKEN, OWNER_CHAT_ID, GEMINI_API_KEY) — never
  in the image, never in the repo. Make sure .env and the Operate/ run dirs are in .gitignore AND
  .dockerignore so no secret and no local media ships.
- Attach a PERSISTENT VOLUME mounted where the run folders live (e.g. /app/Operate), so paid
  media survives a redeploy.
- Give me an exact Railway checklist: init the project from the repo root, set every environment
  variable above, deploy, and watch the logs until the engine connects and the bot reports it is
  running.
Explain what you understood and wait for approval before you build.
```

**Verify end to end:**
1. `railway logs` shows the engine connected (its tools listed) and the bot started.
2. Send the bot a one-line idea from your phone.
3. Walk the four gates as buttons, approve, and confirm the finished video lands in your chat —
   **with your computer off.**

---

## The five hard-won deploy lessons (each is a general rule, not a Pixi quirk)

These came out of moving a working local bot to a running cloud one. Each applies to almost any
personal tool that renders media on a server.

1. **An MCP stdio client spawns the server with a minimal environment — pass the parent env
   explicitly.** When the bot launches the engine over stdio, the child process does **not**
   inherit your shell's environment by default, so `GEMINI_API_KEY` never reaches the engine and
   every media call fails. Pass the parent environment into the transport explicitly (e.g.
   `StdioTransport(..., env=dict(os.environ))`).
2. **A base image that ships a browser may not ship the matching pip package — pin it.** An image
   built to include a browser can still be missing the Python library that drives it, or ship a
   version that does not match the bundled browser. Pin the driver package to the version the
   image's browser expects; do not assume "the browser is here" means "the library is here."
3. **The browser refuses to sandbox as root — start root only to `chown`, then drop privileges.**
   A headless browser will not run its sandbox as root, but the container often starts as root to
   set up the persistent volume. Start as root **only** long enough to `chown` the volume, then
   **drop to an unprivileged user** for the process that renders the code layers.
4. **ffmpeg filtergraphs must be portable — never reuse a stream label.** A filtergraph that reuses
   the same output label (e.g. `[vo]` twice) is accepted by some ffmpeg builds and **rejected** by
   others, so a chain that worked locally can fail in the container. **Split explicitly** and give
   every branch its own label; **mix without auto-normalization** (`amix ... normalize=0`) where
   you need the approved balance preserved, then **verify loudness against the approved reference**
   (the averaging default measured several dB off the intended gain structure; an explicit split +
   `normalize=0` + loudnorm held within ~1 dB).
5. **The music model can refuse a derived prompt — fall back automatically.** A `generate_music`
   prompt derived from the script's wording can come back **`content_blocked`**. Catch it and
   **fall back automatically to a proven mood**, and keep music prompts to **instrumental texture
   / tempo words only** — no lyrics, no derived narrative phrasing that can trip a content filter.

---

## Operations facts (know these before you run it in anger)

- **A persistent volume keeps paid media across redeploys.** Without a volume, the container disk
  is ephemeral and paid media vanishes on every redeploy; the delivered video is always in the
  chat regardless, but attach the volume so run logs and media survive.
- **Job state is in-memory.** A redeploy **mid-job** resets the conversation: media already on the
  volume survives, but the in-progress job state is lost — a resent idea gets a **new slug** and
  does not auto-adopt the old media. Finish a job before redeploying, or expect to restart it.
- **Exactly one poller per bot token.** Telegram allows one poller against a token. Before you
  bring the cloud service up, **stop the local bot**; to work locally again, **pause the Railway
  service first** (scale to 0 / bring it down). Never both at once, or Telegram returns 409
  Conflict and neither works reliably.
- **Silence HTTP-level logging.** The underlying HTTP client can log request URLs at INFO — and a
  Telegram request URL **contains the bot token**, so INFO logging leaks the token into your logs.
  Set that logger above INFO so the token never prints.

**End state:** a real phone-to-video run with the computer off — the finished tool, the whole
thing, yours, running on your accounts only.

---

## Troubleshooting

- **The bot crashes on deploy** → a missing Railway variable. Read the logs, add it, and Redeploy
  (Railway doesn't always pick up changes automatically — redeploy manually).
- **Media calls fail in the cloud but worked locally** → the engine child didn't get the API key.
  Pass the parent env into the stdio transport (lesson 1), and confirm `GEMINI_API_KEY` is set as
  a Railway variable.
- **The code layers fail to render** → the browser driver package doesn't match the image's
  browser (pin it, lesson 2), or the browser is trying to sandbox as root (drop privileges,
  lesson 3).
- **The audio comes out wrong / ffmpeg errors in the container** → a reused stream label or the
  averaging default (lesson 4); split explicitly, `normalize=0`, verify loudness.
- **Music generation 400s** → a `content_blocked` derived prompt; fall back to a proven mood and
  keep the prompt to instrumental texture/tempo words (lesson 5).
- **The bot answers 409 / two instances fight** → a poller is running in both places. One poller
  per token; stop the local one or pause the Railway service.
- **The bot token showed up in the logs** → HTTP INFO logging is on; raise that logger's level and
  rotate the token (it's burned).
