# Plan 6 — Build the App

**Goal:** wire the units into one running command-line tool. Start with the thinnest slice that
works end to end — a link in, a local Hebrew note out — then grow it into the full system with
GitHub storage and the dashboard.

**How to run this plan:** open a **new, clean Claude Code window** in your project folder, turn on
**PLAN MODE**, and paste the master brief below. Let Claude produce a plan, review it, approve it,
then let it build. Have your categories (plan 2), the download + read units (plan 3), and
the processor (plan 4) built and tested before you start here.

> Why PLAN MODE: this is the wiring of the whole system. You want Claude to lay out the files and
> the flow, and you want to approve that map, before a line of code is written.

---

## Stage 1 — the thin slice (local output)

Prove the whole shape works before you add breadth. **What makes this a "thin slice" is that
output stays LOCAL — not that the flow is trimmed.** The full download → read → process → format
chain runs; the only thing Stage 1 leaves out is GitHub and the dashboard.

```
Build a command-line tool in Python that connects the units into one flow.
Start with the THINNEST slice that runs end to end on my own machine.

STACK:
- Python 3.11+.
- Import the downloader + reader (plan 3), the processor (plan 4), and the formatter
  (plan 5, layer 1) — do not rewrite them.
- Driven by environment variables (python-dotenv). Required for this slice: GEMINI_API_KEY.
  Exit immediately with a clear message if it is missing.
- Load dotenv with override=True (load_dotenv(override=True)) so the local .env ALWAYS wins.
  Never rely on — or set — global/user-scope environment variables: on Windows a stale
  user-scope value silently overrides the .env and you debug a ghost. Keys live in the local
  .env only.

CLI:
- `python toki.py <video_url> --local`  → run one link, save the note as a LOCAL file.
- `python toki.py --batch urls.txt --local` → read URLs from a file (skip lines starting with
  #), process each in turn, print a summary table at the end.

THE SLICE (process_url):
- download video → read (speech + on-screen text) → process with Gemini → format to Markdown.
- Save the note to ./output/<category>/<slug>.md (local, dated).
- Clean up the temp video afterward.
- Print each stage as it runs, and at the end print the note's title, category, and relevance.

DO NOT build yet: GitHub push, the dashboard, the Telegram bot, or deploy. Keep this slice lean —
it is only here to prove the chain works end to end.

Show me your plan first: the files, the libraries, the flow. Explain what you understood and wait
for approval before you build.
```

### Decisions to bake into the app layer

These belong in the plumbing (the CLI/plumbing), never in the processor prompt:

- **ASCII temp video name.** Download to `.work/<video_id>.<ext>` — an ASCII name picked up
  front, because a non-ASCII filename breaks the Gemini upload header (plan 3). The video id is
  already ASCII; keep it that way.
- **Cache + cleanup.** Reuse a cached `.work/<video_id>.<ext>` if present; delete temp files after
  a successful run.
- **Print status in English.** The tool prints progress in English/emoji. The **Hebrew** content
  lands in the `.md` note (and later the dashboard), which render correctly in your editor and
  browser — never in the raw terminal.

> **Trap — Windows terminal has no bidi.** Hebrew printed to the Windows terminal comes out
> reversed and unreadable. So keep terminal output English, and if you want a run log, write it
> to a file (e.g. `out/toki.log`) and open it in VSCode, which renders RTL correctly and updates
> live. Never rely on reading Hebrew in the console.

**Test the slice:** `python toki.py "<a real short-video link>" --local`, watch the stages print,
and confirm a Hebrew `.md` note lands in `output/` under the right category. **When this works,
you have seen the brain alive** — a link in, a structured Hebrew note out.

---

## Stage 2 — grow it to the full system

Now bring in everything the earlier plans built. Do these in order, testing after each — and let
the oven hand you one at a time.

1. **GitHub storage** — switch output from local files to the repo (plan 5, layers 2). Add
   `python toki.py --init` to create the category folders, and drop `--local` to push:
   `python toki.py <url>` now writes the note to GitHub and updates the README index.
2. **The dashboard** — wire `update_index()` to regenerate `docs/index.html` on every push
   (plan 5, layer 3), then enable GitHub Pages (plan 5, layer 4).
3. **Batch at scale** — confirm `--batch` works against GitHub (many links, one index rebuild at
   the end rather than per-link, if you want to keep it fast).
4. **Config as one source of truth** — confirm the categories config feeds the processor, the
   formatter's folder paths, and the dashboard's pills and colors, all from one place.

After stage 2 you have the full Toki running from your machine: a link in, a note in your repo,
and a live dashboard. The Telegram bot and cloud deploy are plan 7.

---

## Troubleshooting

- **Crashes on startup** → a missing environment variable. Read the error, fill the key, rerun.
- **Hebrew prints as gibberish in the terminal** → expected; read the note file or the log in
  VSCode, not the console.
- **The same link is processed twice in a batch** → de-duplicate on the video id before
  processing.
- **`--local` works but GitHub push fails** → `GITHUB_TOKEN` scope or `GITHUB_REPO` format (plan
  1 troubleshooting).
- **A stale value keeps coming back after you edited `.env`** → a user-scope env var is
  overriding it; you didn't load dotenv with `override=True`, or you're reading a global. Check
  `[Environment]::GetEnvironmentVariable('NAME','User')`.
