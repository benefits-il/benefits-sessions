# Plan 4 — The Processor (the soul)

**Goal:** build the brain that turns a video reading into a rich, structured Hebrew knowledge
note — classified, translated, enriched, and fact-checked. This is Toki's deliverable — the
thing you actually read and keep — and its identity is the heart of the whole tool. Do not water
it down.

The processor now receives **two channels** (speech + on-screen text), not a single transcript.
Every tool row carries its own category and its own source. If you have written a note-identity
document during station 4 (the second soul), it is the authority for the output shape — where
this plan and that document ever disagree, **the document wins.**

**How to build it:** two parts — (a) a **processor prompt** (an external, hot-editable file that
IS the brain), and (b) a small **runner** that feeds a reading to Gemini with that prompt and
parses the result. Lock the note's identity with the oven (station 4) first, then give the briefs
below to your meta-agent.

> Engine: **Gemini**, model from `PROCESSOR_MODEL` (default `gemini-3.5-flash`), with Google
> Search grounding enabled so it can verify tool URLs and repos. One input, one output. It does
> not greet, ask questions, or chat.

---

## The core identity — this is non-negotiable

**The processor is a structured extractor and verifier, NOT a transcriber.** It reorganizes the
reading into a clean, scannable Hebrew note — and it checks its own claims against the web. If the
note could be replaced by a transcript without losing anything, it failed.

**The two-list rule:**
- **REMOVE:** filler, false starts, "um", repetition, empty self-promotion, "follow me", "link in
  bio", narration of what is on screen when it carries no information. (Noise.)
- **NEVER REMOVE:** tool names, URLs, repos, numbers, prices, free-tier limits, specific claims,
  tips, action items, model names — anything a reader would later want to find. (Signal.)

**Classify before extracting.** Pick the category first, then extract through that lens. The
category is one of the slugs from the config discovered in plan 2 — never invent one outside that
set; when nothing fits, use `other`.

---

## Three rules the live run proved — do not drop these

### 1. Silence is normal
A reading with an empty speech transcript and a populated on-screen text is a **completely valid
input** — the dominant case in this genre. The processor must produce a full note from on-screen
text alone, and must **never** lower relevance, add a "no speech" verification note, or produce a
"broken input" note merely because nobody spoke. The on-screen text is the content.

### 2. Sweep ALL on-screen text, not just numbered items
In the live run the model read a tool's name into the on-screen text but then failed to promote it
to the tools list, because it clung to the video's numbered list (1, 2, 3) and the tool had no
number beside it. A real tool was lost.

**Rule:** every brand name, product name, logo, and URL appearing anywhere in the on-screen text
is a **candidate tool** — not only items in a numbered list. An item that was read but not promoted
is a bug, not a judgement call. The video's own count ("4 amazing tools") never caps your table;
creators routinely show extras they never counted, and those extras are often the most useful thing
in the clip.

### 3. Two-level categories
A "5 useful sites" video routinely spans four categories at once and has no single correct one. So
classify **twice**: **the note** gets one dominant category (the category of most of its tools; on
a tie, the category of the tool the video opens with), and **every tool row** carries its own
category. Nothing is lost, and one-category-per-note still holds — the note is filed under its
dominant category while each tool stays independently filterable.

---

## Part A — the processor prompt (external, hot-editable)

Build this as a standalone Markdown file (e.g. `processor-prompt.md`) that is loaded fresh at run
time — so you can tune the extraction style later without touching code. Give this brief to your
meta-agent:

```
Write a processor system prompt for a knowledge-extraction tool. It receives ONE message (video
metadata + a two-channel video reading) and outputs ONE structured note as strict JSON. It is not
interactive.

Embed all of the following:

1. IDENTITY: "You are a knowledge extraction, classification and verification engine — not a
   transcriber. You receive a reading of a short tech video (spoken words AND on-screen text) and
   produce a structured Hebrew knowledge note." Include the two-list rule in full.

2. INPUT SHAPE: the model receives BOTH channels separately — speech_transcript (may be empty)
   and onscreen_text (an array of blocks). State explicitly: an empty speech_transcript with a
   populated onscreen_text is NORMAL and must produce a full note. Never lower relevance for
   silence; never add a verification note about the video having no speech.

3. SWEEP RULE: every brand name, product name, logo or URL appearing ANYWHERE in onscreen_text is
   a candidate tool — not only items in a numbered list. Reading something and omitting it from
   tools_mentioned is an error. The video's own count never caps the table.

4. THE USER'S CATEGORIES: embed the full CATEGORIES config from plan 2 — for each: slug, Hebrew
   name, English name, and a detailed description with example topics and its boundary rule.
   Classify into EXACTLY ONE slug from this set. Use "other" ONLY when nothing genuinely fits.
   Include any tie-breakers the config settled on (e.g. output beats domain · implementation beats
   intent · product beats method).

5. TWO-LEVEL CATEGORY: assign a category to the NOTE (dominant; on a tie use the category of the
   first tool shown) AND a category to EVERY row in tools_mentioned.

6. RELEVANCE (1-5): 5 = can act on it tomorrow, in an active area · 4 = directly relevant, needs
   learning or a signup · 3 = useful to know it exists, not urgent · 2 = tangential or duplicates
   something known · 1 = promotional, empty, or unreadable input. A note rated 1-2 is still saved
   in full — short, with a verification note explaining why it is weak.

7. OUTPUT FIELDS (strict JSON, no markdown fences, no preamble):
   - title_he, title_en
   - category (one slug)
   - relevance (integer 1-5)
   - summary_he (2-4 Hebrew sentences: what the video GIVES, not what it does). NEVER open the
     summary by describing the video ("הסרטון מציג...", "בסרטון זה...", "סקירה של...") — start
     with the substance itself; the frontmatter already tells the reader where the note came from.
   - key_insights (array of Hebrew strings; may be empty for a clean list video — an empty array
     beats padding). Enrichment you add yourself must be marked as yours, prefixed
     "(העשרה — לא מהסרטון)".
   - tools_mentioned: array of { name, category, url, desc_he, source, verified }
       name     = the brand name, not the domain (e.g. `BrandName`, not `brandname.com`)
       source   = "spoken" | "onscreen" | "both"
       verified = "yes" | "no" | "unchecked"
   - repos_mentioned (array of { repo, url, desc_he })
   - action_items (array of Hebrew strings)
   - verification_notes (array of Hebrew strings)
   - tags (array of lowercase English tags for search)

8. ENRICHMENT + VERIFICATION (the skepticism soul — do not drop it): use web search to find the
   correct official URL for every tool and confirm every repo exists.
   - NEVER invent a URL, and NEVER "correct" unreadable text into a guess.
   - When on-screen text is uncertain, search by the tool NAME to recover the real URL. This
     works: in the live run a blurry tool name read at only medium confidence was recovered and
     verified correct by searching for it, rather than guessed at.
   - Any claim carrying a number ("saves 10 hours", "1M+ sites") goes to verification_notes, not
     to key_insights.
   - An EMPTY verification_notes on promotional content is suspicious — a marketing video with
     nothing flagged means the check was shallow.

9. LANGUAGE RULES: body in Hebrew; technical terms and tool/library/repo names stay in English
   as-is (never transliterate); URLs stay exactly as-is. Both a Hebrew and an English title — the
   English one is what will be searched for years later, so make it descriptive.

10. EDGE CASES: unreadable input on BOTH channels → this should have been stopped upstream; if it
    reaches you, category "other", relevance 1, and say so. Promotional → "other", relevance 1,
    verification note "תוכן פרסומי". Content spanning categories → the NORMAL case; use the
    two-level rule, do not agonize.

Explain what you understood and wait for approval before you write it.
```

---

## Part B — the runner

```
Build a small processor runner function.

INPUT: the VideoReading (speech_transcript, onscreen_text, spoken_language), the VideoMeta
(video_id, title, creator, duration_seconds, source_url, platform), and the processor prompt
loaded from its external file.

ENGINE: Gemini (GEMINI_API_KEY), model from PROCESSOR_MODEL. Assemble the user message as a
metadata block + BOTH channels, clearly labelled and separated, in the shape the processor prompt
expects.

SPLIT INTO TWO CALLS — this is the shape the live run settled on:
  1. EXTRACT + CLASSIFY, ungrounded (no Search). Fast and stable. Returns the full note with every
     tool marked verified="unchecked".
  2. VERIFY, grounded (Search on), in SMALL BATCHES of tools (~5 per call), best-effort. For each
     batch, confirm the URLs and set verified to "yes"/"no".
  A verification batch that fails (times out, errors) leaves those tools "unchecked" and MUST NOT
  fail the note — "unchecked" is an honest value the schema already carries. Verification can never
  kill a note.
  (Why the split: a single call that both extracts AND verifies a tool-dense video times out —
  the live run hit 504 DEADLINE_EXCEEDED even at a long timeout, while the same extraction with no
  grounding finished in ~13 seconds. Separate the fast, ungrounded extraction from the slow,
  grounded verification, and chunk the slow part.)

PARSE: the model returns strict JSON. Ask for a response schema so the fields (and the category
enum) are enforced. On current Gemini (3.x), Search grounding and a response schema DO combine —
you do NOT need the old markdown-fence stripping or regex-extraction fallback that earlier model
versions required; drop them. (One trade-off: when a response schema is set, grounding metadata
comes back empty, so you lose the citation trail — that is acceptable here.) Then VALIDATE:
  - the note category must be a known slug, else "other"
  - EVERY tools_mentioned[].category must be a known slug, else "other"
  - relevance clamped to 1-5
  - source must be one of spoken|onscreen|both, else "onscreen"

STAMPED BY THE TOOL, NOT THE MODEL: processed (today's date from the system clock), has_speech
(derived: spoken_language != "zxx" AND the transcript is non-empty), tools_count
(len(tools_mentioned)), plus video_id / platform / duration_sec / source_url / creator / language
carried straight from VideoMeta and the reading. Never ask the model for the date, and never let
it invent metadata it was already given.

ENFORCE INVARIANTS IN CODE, not just in the prompt: if has_speech is false, no tool may be
source="both" or "spoken" — nothing could have been spoken. Stamp such facts in code rather than
trusting the model to respect them.

OUTPUT: a ProcessedNote object carrying exactly the frontmatter field set defined in the note
identity (station 4). Keep it in one small function the app can import.

Explain what you understood and wait for approval before you build.
```

> **Gemini 3 — `thought_signature`.** With Search grounding on, Gemini runs a small tool loop
> (search → results → answer) and attaches a `thought_signature` to the content it returns. When
> you feed the model's own prior turn back inside that loop, return the content **exactly as the
> SDK gave it** — don't rebuild it from just the text. Rebuild it and Gemini answers **400**.

---

## What "done" looks like

- Feed it a reading and get back a valid JSON note: a Hebrew title, exactly one of your categories,
  a 1-5 relevance, a Hebrew summary, key insights, a tools table where **every row has its own
  category and source** and the URLs are **real** (web-verified), repos, action items, and any
  dubious claims in verification_notes.
- **A silent video produces a full, well-rated note.** This is the acceptance test that matters.
- Nothing that appeared in the on-screen text is silently missing from the tools table.
- The tool URLs are correct (verified against the web), not hallucinated.
- Change a line in the processor prompt file and the next run reflects it — no code change.

## Notes for the build

- The processor prompt is the brain. **Fix output by editing the prompt, not the code.** When a
  run comes out well, keep what worked; when a note has the wrong category or a banned summary
  opener, that is a prompt fix — keep the prompt hot-editable and the code stable.
- The categories config (plan 2) is embedded in the prompt. When you change categories, update the
  prompt in the same commit so the two never drift apart.
- Keep the runner small and importable — the app (plan 6) calls it right after the reader.
