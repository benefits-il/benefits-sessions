# Plan 5 — Store & Dashboard

**Goal:** give Toki its archive and its face. Three things: (1) format each note as clean
Markdown, (2) save every note into **your** GitHub repo with an auto-generated index, and (3)
render a searchable HTML dashboard on GitHub Pages. This is where Toki stops being a one-shot
script and becomes a knowledge base you can browse.

**Do this after the trial slice works** (a link flows through to a local Markdown note in plan
6, stage 1). Then switch storage from local files to GitHub, and add the dashboard on top.

> The axiom: everything stays with you. The repo here is **your** repo, the token is **your**
> token — no shared account.

---

## Layer 1 — the formatter (Markdown + frontmatter)

Turn a ProcessedNote into a Markdown file with YAML frontmatter, filed under its category.

```
Build a formatter unit.

INPUT: a ProcessedNote (plan 4) + the video metadata.
OUTPUT: a Markdown string with YAML frontmatter, and a file path.

FRONTMATTER — this exact field set (defined by the note identity, station 4), in this order:
  title_he, title_en, category, relevance, platform, creator, video_id, source_url,
  duration_sec, language, has_speech, tools_count, tags, processed (YYYY-MM-DD, stamped by the
  tool). has_speech may be false with tools_count > 0 — that is a NORMAL silent-video note, never
  an error.
BODY (Hebrew section headers, EXACTLY as written — the index reader parses them back, so a single
character of drift breaks it):
  ## תקציר
  ## תובנות מפתח
  ## כלים            → a table: שם | קטגוריה | קישור | מה זה עושה | מקור | אומת
  ## ריפוזיטוריז
  ## פריטי פעולה     → checkbox list
  ## הערות אימות
Omit any section that has no content — never print an empty "N/A" section. In the tools table map
source to נאמר|מסך|שניהם and verified to ✅|⚠️|— .
FILE PATH: <category>/<YYYY-MM-DD>_<slug>.md, where slug is a slugified title_en — lowercase,
hyphenated, ASCII ONLY, max ~50 chars. A Hebrew filename breaks the tooling; do not allow one.

Write every file with encoding="utf-8" explicitly. On Windows the default is cp1252 and Hebrew
content raises UnicodeEncodeError.

Explain what you understood and wait for approval before you build.
```

---

## Layer 2 — GitHub storage + index

Push each note to the repo and regenerate a browsable index.

```
Add GitHub storage using the PyGithub library and the GITHUB_TOKEN / GITHUB_REPO / GITHUB_BRANCH
environment variables.

- existing_path_for(video_id): search the notes already in the repo for one whose frontmatter
  video_id matches, and return its path (or None). Identity is keyed on video_id, NOT on the
  slug — the model-generated title_en drifts between runs (in the live run a re-run renamed the
  very same note, so its slug changed), so keying on the slug files a duplicate note on reprocessing.
  Before saving, reuse the existing path if one is found and update it in place.
- save_note(filepath, content, title): if the file exists, update it (commit "Update: <title>");
  if not, create it (commit "Add: <title>"). Return a dashboard deep-link anchor built from the
  filepath (replace "/" and "_" with "-", drop ".md").
- init_repo(): create a .gitkeep in each category folder so the structure exists up front.
- update_index(): read every .md across the category folders, parse the frontmatter and body of
  each, sort newest-first by `processed`, and regenerate: (a) a README.md with a per-category
  table (date, Hebrew title, source link, relevance as stars) and a total count, and (b) the
  HTML dashboard file (layer 3), written to docs/index.html. Push both. Build the index ONCE at
  the end of a batch, not after every link — a failed index rebuild must never lose notes that
  were already pushed.

Explain what you understood and wait for approval before you build.
```

> **Commit messages: use `+`, not the word "plus."** Keep commit messages plain ASCII and short.

---

## Layer 3 — the dashboard (the face of the archive)

A single self-contained HTML file, generated from the notes, served on GitHub Pages. There is a
ready design theme — dark, calm, card-based — that you can adopt as-is or replace with your own
look. Give this brief to your meta-agent or build it directly:

```
Build a dashboard generator: generate_dashboard_html(notes) -> a single self-contained HTML
string (all CSS inline in <style>, all JS inline in <script>). No external dependencies except
Google Fonts and the Lucide icons CDN.

DESIGN — a dark, glass-morphism theme. Tokens:
  --bg #070B14 · --bg-elevated #0F1629 · --surface rgba(255,255,255,.04) ·
  accents: emerald #10B981, violet #8B5CF6, sky #38BDF8, amber #F59E0B ·
  --white #E2E8F0 · --muted #94A3B8 · --border rgba(255,255,255,.06) · --radius 16px.
  Fonts: Space Grotesk (headings) + Inter (body). Icons: Lucide via CDN.
  Each category uses its icon + accent color from the config (plan 2).

SECTIONS (build all):
  1. A soft mesh-gradient background (a few large blurred drifting circles; CSS only).
  2. Hero: a small "Knowledge Base" pill, a large gradient heading, a one-line subtitle.
  3. Stats bar: 3 glass cards — note count, category count, average relevance — animated counters.
  4. A full-width search input (filters cards live).
  5. Category filter pills ("All" + one per category, each with a count badge and its icon).
  6. A responsive cards grid (auto-fill, min ~400px). Each card: category icon + name (he · en),
     date, creator, relevance stars; the Hebrew title (large) and English title (muted); the
     summary with an accent left-border; expandable details (insights, tools, action items,
     verification warnings); a tags row; a source-link button. Staggered reveal on scroll; hover
     lifts the card.
  7. Deep-link support: a URL hash maps to a card id → scroll to it, expand it, pulse-highlight.
  8. A scroll-to-top button.
  9. A footer with the last-updated timestamp.

BEHAVIOR: RTL layout (<html lang="he" dir="rtl">). HTML-escape all note content (prevent XSS).
Respect prefers-reduced-motion. Single column on mobile. Build each card's anchor id from its
file path (replace "/" and "_" with "-", drop ".md").

Explain what you understood and wait for approval before you build.
```

---

## Layer 4 — enable GitHub Pages (manual)

Once `docs/index.html` is being pushed:

1. Repo → **Settings → Pages**.
2. Source: **Deploy from a branch**. Branch: `main`, folder: `/docs`. Save.
3. Wait a minute or two. Your dashboard is live at `https://<your-username>.github.io/<your-repo>/`
   (replace both, brackets included).

---

## What "done" looks like

- Process a link and a new `.md` note appears under its category folder in **your** repo, the
  README index updates, and the dashboard regenerates.
- Open the dashboard URL: your notes show as cards, search filters them, the category pills work,
  and relevance shows as stars.
- A note's deep link (README → dashboard) scrolls to and opens the right card.
- Edit `processor-prompt.md` and the next note reflects the change — the archive keeps growing in
  your own repo, on your own account.

## Notes for the build

- The dashboard is generated, never hand-edited — it is rebuilt from the notes on every
  `update_index()`. Style lives in the generator; content lives in the notes.
- Keep the note parser tolerant: it reads back frontmatter and the Hebrew section headers you
  wrote in layer 1, so those header names must match exactly on write and on read.
