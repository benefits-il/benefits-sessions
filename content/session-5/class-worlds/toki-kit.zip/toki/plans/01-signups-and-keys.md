# Plan 1 — Signups & Keys

> **Do this first. Nothing runs without it.** Every part of Toki is driven by keys stored
> as environment variables. A single missing value makes the tool crash on startup. By the
> end of this plan you have a filled table with a real value for every variable.

## Two handling rules — keep these the whole way

- **A key goes in your terminal or your `.env` file only — never in the chat.** Don't paste a
  token or API key into the conversation with Claude, into a prompt, or into any message. If a
  key ever lands in a chat, treat it as burned: go back to its source and **rotate it** (issue
  a new one, revoke the old). Pasted it in chat ← rotate the key.
- **Placeholders include their brackets.** Wherever a plan writes something like `<your-token>`
  or `<your-username>`, you replace the **whole** thing — the angle brackets too. `<...>` never
  stays in a real command or file; the brackets are part of what you delete, every occurrence.

## The key table — fill this before you build

Keep this table open (Notion, a sheet, a note) and fill each row as you go. Write down
**which account** you used for each — when something breaks later, you'll know where to look.

| Variable | Where to get it | Needed for | Value | Account |
|---|---|---|---|---|
| `GEMINI_API_KEY` | aistudio.google.com | Trial run | | |
| `GITHUB_TOKEN` | GitHub developer settings | Full system — storage | | |
| `GITHUB_REPO` | `<your-username>/<your-repo>` | Full system — storage | | |
| `GITHUB_BRANCH` | usually `main` | Full system — storage | | |
| `TELEGRAM_BOT_TOKEN` | @BotFather on Telegram | Deploy — the bot | | |
| `ALLOWED_USER_IDS` | @userinfobot on Telegram | Deploy — bot security | | |

> The first row is all the trial run needs. GitHub (rows 2–4) is **core** to the full system —
> it is where your notes live and how the dashboard is served — so you'll get to it soon. The
> Telegram rows belong to deploy (plan 7).

---

## Trial-run key (get this now)

### 1. Gemini API key — `GEMINI_API_KEY`

You loaded this key (and ~$15 of credit) into your vault during prep. To confirm or renew:

1. Go to **aistudio.google.com** and sign in.
2. **Get API key → Create API key**, copy it.

> This one key powers the whole system — reading the video and processing it. Make sure billing is
> enabled (the free tier returns nothing for media).

> **Model note for a fresh key:** `gemini-2.5-pro` returns **404** for newly created API keys —
> do not use it. The live run settled on `gemini-3.5-flash` for both the reader and the processor
> (overridable via `READER_MODEL` and `PROCESSOR_MODEL`). Gemini model ids move over time; if one
> 404s, check the current list in AI Studio and swap it.

**At this point you have everything the trial run needs. Go discover your categories (plan 2)
and build the units (plans 3, 4).**

---

## Full-system keys — GitHub (the storage home)

Toki saves every note into **your own** GitHub repo, and serves the dashboard from it. This is
core to the tool. The oven walks you through it when you reach plan 5.

### GitHub personal access token — `GITHUB_TOKEN`

1. Go to **GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)**.
2. **Generate new token (classic)**, name it (e.g. "toki"), and select the **`repo`** scope
   (full control of repositories — the token needs to write files and update the index).
3. Generate and copy the token → `GITHUB_TOKEN`.

> **Quick path vs. the safer one.** A classic `repo` token is the fastest way to get going, but it
> can touch every repository you own. The safer choice — and the one deployment principle 6 (plan 7)
> recommends before you go to the cloud — is a **fine-grained PAT scoped to the single archive repo**
> with only **Contents** and **Pages** set to read/write and everything else No access. The live run
> started on the broad classic token and swapped in a narrow one before deploying; you can do the
> same, or start narrow from the outset.

### The repository — `GITHUB_REPO`, `GITHUB_BRANCH`

1. Go to **github.com/new** and create a repository (any name — you own it). Make it **Public**
   so free GitHub Pages can serve the dashboard. **Don't** initialize it with a README — Toki
   generates its own.
2. `GITHUB_REPO` is `<your-username>/<your-repo>` (replace both, brackets included).
3. `GITHUB_BRANCH` is usually `main`.
4. **GitHub Pages** (for the dashboard) is enabled later, in plan 5, once the dashboard exists.

---

## Deploy keys (get these last, for plan 7)

### Telegram bot token — `TELEGRAM_BOT_TOKEN`

Needed only for the optional bot that lets you send a link from your phone.

1. In Telegram, open a chat with **@BotFather**.
2. Send `/newbot`, choose a display name and a username ending in `bot`, and BotFather returns
   the token → `TELEGRAM_BOT_TOKEN`.
3. Already have a bot? Send `/mybots`, pick it, choose **API Token**, copy it.
4. Give your bot a face: in the same **@BotFather** chat send `/setuserpic`, pick your bot,
   and upload `assets/toki-profile.png` from this kit. Now Toki is easy to spot in your chat list.

### Your Telegram user id — `ALLOWED_USER_IDS`

Locks the bot to you only, so no one else can drive it.

1. Message **@userinfobot** on Telegram; it replies with your numeric user id.
2. Put it in `ALLOWED_USER_IDS` (comma-separated if you ever add more).

### Railway — the cloud host

1. Go to **railway.app**, sign up (you can use GitHub).
2. No key needed yet. During deploy you'll connect your project and paste all the variables.

---

## Troubleshooting

- **The tool crashes the moment it starts** → a missing environment variable. Read the error,
  find the empty key, fill it, run again.
- **A value looks stale on Windows** → user-scope environment variables override `.env`. Check
  `[Environment]::GetEnvironmentVariable('NAME','User')`, not just the file. A new process is
  required to see a change. (In code, load the local `.env` with `override=True` so the file
  always wins — see plan 6.)
- **GitHub push fails** → check `GITHUB_TOKEN` has the `repo` scope, and `GITHUB_REPO` is in
  `<your-username>/<your-repo>` form with the brackets removed.
