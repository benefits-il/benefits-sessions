# Plan 3 — Download & Read

**Goal:** build the two units that turn a video link into text — (a) a **downloader** that pulls
the **video** from the link, and (b) a **reader** that turns that video into both the spoken
words and the on-screen text. The processor (plan 4) depends on that reading.

**How to build it:** the downloader is plain automation code Claude Code can write directly; the
reader is a small skill best handed to your meta-agent (the agent whose whole job is to build
other agents and skills). Test each with the demo link (or your own) before wiring anything else.

> Engine for reading: **Gemini**, multimodal, model from `READER_MODEL` (default
> `gemini-3.5-flash`). Reading a video is deterministic work — same input, same kind of output —
> so it is a skill, not a conversational agent.

---

## Why this reads the video, not just the audio

Toki targets short tech videos, and a large share of them **have no speech at all** — every tool
name and every URL exists only as text rendered on screen (a "here are 5 sites" clip that just
shows them). The live run proved this out: on real links from every platform, the payload lived
entirely in the on-screen text.

An audio-only chain would have returned **nothing** for those, and a stop-point like "empty
transcript = music only, stop" would have deleted them silently. So the downloader keeps the
**video**, and the reader returns **two channels**: the spoken words *and* the on-screen text.
Either channel alone is enough to produce a note.

| | Audio-only (old) | Read-the-video (now) |
|---|---|---|
| Downloader output | an `.mp3` (ffmpeg strips the video) | the **video file**, unmodified |
| Unit 2 | "transcribe" — audio → text | "read" — video → speech **+ on-screen text** |
| Stop-point A | ffprobe finds an audio stream | file downloaded and has a **video** stream |
| Stop-point B | empty transcript stops | stops only if **both** channels are empty |
| ffmpeg | required, for extraction | needed for `ffprobe` only — no re-encoding |

---

## Unit A — the downloader (yt-dlp)

Keep the video; do not extract audio. No ffmpeg re-encoding — `ffprobe` is used only to confirm
a video stream exists.

```
Build a downloader unit for a video-to-knowledge tool. Python, using yt-dlp as a subprocess
(not the Python bindings). Do NOT re-encode or extract audio — keep the downloaded video as-is.

INPUT: a video URL.
OUTPUT: a VideoMeta object — { video_id, title, creator, duration_seconds, video_path,
source_url, platform } — where video_path points to the downloaded video file and platform is
the site detected in step 1 (stored here so the formatter can write it to the note frontmatter).

STEPS:
1. Detect the platform from the URL (youtube | facebook | instagram | tiktok | other) and
   extract a stable video id. Fall back to a hash of the URL tail if no id is found. Keep
   detection general — yt-dlp supports many short-video sites; do not hard-code one.
2. Fetch metadata with `yt-dlp --dump-json --no-download` (title, uploader, duration).
3. LENGTH GUARD: read MAX_DURATION_SECONDS from env (default 600). If the video is longer,
   STOP with a clear message. Video tokens cost roughly an order of magnitude more than audio;
   an unbounded long video is the one real cost risk in this tool.
4. Cache: if `.work/<video_id>.<ext>` already exists, skip the download and reuse it.
5. COOKIES: read COOKIES_FROM_BROWSER from env. Some platforms (e.g. Instagram) REQUIRE a
   logged-in browser profile — anonymous requests get an "empty media response". Most (YouTube,
   Facebook, TikTok) do NOT need it. Apply the `--cookies-from-browser <value>` flag when the
   value is set; on a failure that looks auth-related, retry once WITH the flag even if it was
   unset. IMPORTANT: use Firefox. Chrome and Edge cannot be read — since Chrome 127 they encrypt
   their cookie store in a way yt-dlp cannot open, and the download fails outright. This is not
   fixable in code; use a logged-in Firefox profile.
6. Download the video with a format-fallback chain — try "b", then "bv*+ba/b", then "ba/b", then
   no format flag — because short-video sites change their formats often and one usually works.
7. VERIFY (stop-point A): confirm the file exists, is non-trivial in size, and has a VIDEO
   stream (`ffprobe -v quiet -select_streams v -show_entries stream=codec_type -of csv=p=0`).
   Do NOT check for an audio stream — a silent video is a completely valid input here. If there
   is no video stream, STOP and report it.
8. Return VideoMeta.

Give me a cleanup(video_id) that removes temp files from `.work/`. Explain what you understood
and wait for approval before you build.
```

> **Windows + ffmpeg:** if you installed ffmpeg via WinGet in session 4, it may live outside
> PATH. Have config detect it by scanning
> `~/AppData/Local/Microsoft/WinGet/Packages/*FFmpeg*/*/bin` and add it to PATH if found.

> **Optional dependency:** if downloads fail on sites that gate by client impersonation,
> install `curl_cffi` (`pip install curl_cffi`) as an optional yt-dlp helper.

---

## Unit B — the reader (Gemini, multimodal)

This replaces the old transcriber. It sends the **video** to Gemini and gets both channels back
in a single call.

```
Build a video-reading skill for a short-video knowledge tool.

INPUT: a path to a video file (mp4).
OUTPUT: a VideoReading object with BOTH channels, kept separate:
  - spoken_language: ISO code, or "zxx" when there is no speech at all
  - speech_transcript: verbatim speech in the SOURCE LANGUAGE, empty string if none
  - onscreen_text: an array of every distinct block of text visible on screen, verbatim
    as rendered

ENGINE: Google Gemini, model from the READER_MODEL env var (default gemini-3.5-flash), using
the GEMINI_API_KEY environment variable. Upload the video with the File API and poll until its
state leaves PROCESSING. Use temperature 0.

DO NOT translate here — the source language is preserved. Translation to Hebrew happens later,
in the processor.

THE READING PROMPT (keep it in its own external text file so it can be tuned without touching
code) must instruct the model to:
  - Transcribe speech verbatim in its original language. If there is no speech, return an empty
    transcript and "zxx" — this is a NORMAL result, not an error.
  - Read ALL on-screen text: browser address bars, captions, overlays, titles, UI labels, and
    recognizable product logos. Verbatim, as rendered.
  - NEVER guess a URL it cannot actually read, and NEVER "correct" what is rendered into what it
    thinks the text should be. Unreadable → report it as unreadable.

VALIDATION (stop-point B): STOP only if speech_transcript is empty AND onscreen_text is empty.
Either channel alone is enough to continue. Do NOT stop on missing speech — a large part of the
genre this tool targets is silent, text-on-screen video.

TEST: run it on the demo link (or a short clip) and show me both channels.

Explain what you understood and wait for approval before you build.
```

---

## What "done" looks like

- You hand the downloader a link and get back a **video file** plus title, creator, and duration.
  A platform that needs a login works via the Firefox cookie flag; the others work without it.
- A video longer than `MAX_DURATION_SECONDS` is **refused** before any upload happens.
- You hand the reader a video and get back both channels, separated.
- **A video with no speech returns `zxx` + an empty transcript + a populated `onscreen_text`, and
  this passes validation.** If your build stops here, the build is wrong — that silent clip is
  exactly the case Toki exists for.
- Only a video with neither speech nor on-screen text is refused.

## Notes for the build

- The reading prompt lives in its own file — it is an asset you will tune.
- Keep both functions small and importable; the app (plan 6) calls them in order.
- **Trap — non-ASCII filenames break the Gemini upload.** The SDK sends the filename in an HTTP
  header, and a Hebrew name makes the upload fail. `.work/<video_id>.<ext>` is ASCII by design —
  keep it that way. If you ever test the reader on a file with a non-ASCII name, copy it to an
  ASCII path first.
- **Trap — Windows console encoding.** Printing Hebrew or emoji to the terminal crashes with
  `UnicodeEncodeError` under cp1252. Pass `encoding="utf-8"` explicitly on every file write, and
  keep terminal output English (see plan 6).
- Do not add classification, GitHub, or the dashboard here. These two units only turn a link
  into text.
