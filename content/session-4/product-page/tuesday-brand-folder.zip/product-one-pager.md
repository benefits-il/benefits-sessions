# Tuesday — what it is, in one page

## In short

Tuesday is work-management software for the one-person company. Everything a freelancer needs to run their business, in one place: the clients, the invoices, and the tasks. No departments, no assigning work to a team, none of the things that don't matter when you're on your own.

Monday is for companies. Tuesday is for the one-person company. That's the whole story.

## Who it's for

Freelancers and solopreneurs. Designers, developers, consultants, copywriters, coaches, photographers. People who don't have a manager because they are the manager, and the accountant, and the customer support line too.

## The heart of the product — Tasks 2.0

Most task systems were built for teams, so they're stuffed with fields no freelancer needs: who the task is assigned to, who approves it, which sprint it belongs to. When you're alone, all of that is noise.

Tasks 2.0 is a task system that understands you're alone. It connects every task to the client and the invoice behind it, so you always know what you're working on, for whom, and what it's worth.

## Customer Portal

For every freelancer we give a simple portal they send to their client — one place where the client sees the status, approves, and pays, without the endless email thread. It saves the freelancer the coordination work, and makes them look more put-together in front of the client.

## How you start

You start for free. No credit card, no sales call. You sign up and start working. The move to paid happens once the business is already leaning on the tool.

## Why now

AI turned the one-person company from a possibility into the norm. One person now does the work of a team. But the tools still talk to teams. Tuesday is built for this era, for the person who is the whole business.
