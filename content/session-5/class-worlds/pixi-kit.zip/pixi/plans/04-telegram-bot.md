# Plan 04 — The Telegram bot (the home layer, local)

**Runs in its own clean build window, and is built at home.** This is validated end to end — a
one-line idea from the phone comes back as a finished on-brand vertical video, through the same
four gates as inline buttons. This plan ends with the bot **working locally** (the PC must stay
on); deploying it to the cloud so it runs with the PC off is plan 05.

It does not add any new capability — it adds **availability**. The core (plans 01–03) already
produces on-brand video in Claude Code; this wraps that same machinery in a conversational
Telegram bot.

Read plan 00 first. Every media operation is still an engine tool on `gemini-engine`, by its
exact signature — the bot does **not** call the Gemini API directly.

## What the bot is — a second client of the same engine

The bot is a **second client of the same tool layer the student built in Unit 1**. The engine
stays the single wrapper around media; the bot is just another caller of its six functions —
same signatures, same key. Concretely:

- The engine is a local Python MCP server (`server.py` defines the six media functions and loads
  the Gemini key from its own `.env`). In Claude Code those functions are exposed as MCP tools;
  the same tools are reachable from another Python process **over stdio**.
- The bot reaches them through an **in-process MCP client** (`fastmcp.Client` over a
  `StdioTransport`) that **spawns the engine and calls the tools by name** with the identical
  signatures from plan 00. This is the validated path — **not** a plain `import` of the engine's
  functions: under FastMCP the `@mcp.tool` decorator wraps the module-level functions, so they
  are not a callable surface to import; the MCP-client-over-stdio path is how a second process
  reaches them. Because the engine loads `GEMINI_API_KEY` from its own `.env`, the bot never sees
  or handles that key. There is **no** direct model HTTP call anywhere in the bot.
- The bot also **reuses the locked assets from the core**: the identity skill's frozen
  `Design/identity-spec.md` (+ the anchor on Path A, or the sign sprite on Path B), and the brand
  studio's tokens — injected verbatim into every prompt, exactly as the production agent does.

In other words: the bot re-expresses the **same production order and the same four gates** as a
chat, over the **same engine**. It invents nothing new about how media is made, and it makes **no
assumption about a character** — it serves whichever identity path plan 01 built.

## Secrets — two handling rules (same as the rest of the kit)

- **A token goes in your terminal or your `.env` file only — never in the chat.** Do not paste
  the bot token into the conversation, a prompt, or any message. If it lands in a chat, treat it
  as burned: rotate it (get a new token from BotFather, the old one dies). Pasted in chat ←
  rotate.
- **Placeholders include their brackets.** Where this plan writes `<your-bot-token>`, replace the
  **whole** thing, angle brackets included — every occurrence.

Only **one** new secret exists here: the Telegram bot token. **The Gemini key is NOT
re-requested** — it lives in the engine from Unit 1, and the bot reaches media only through the
engine, which loads that key itself.

## Build step A — the bot token, the face, and the single-user guard (BotFather)

**Precondition — how the bot reaches the engine.** The bot uses the **in-process MCP client**
over stdio described above: it launches the engine (`uv run --directory <engine-folder> python
server.py`) and invokes the tools by name with the identical signatures from plan 00. Add a
**smoke test** that diffs every tool's input schema against the plan-00 table before the first
run — if a signature does not match, stop.

You created your bot at home during course prep. To wire it up:

1. In Telegram, open a chat with **@BotFather**.
2. Send `/mybots`, pick your bot, choose **API Token**, copy it.
3. No bot yet? Send `/newbot`, choose a name and a username ending in `bot`, and BotFather
   returns the token.
4. Give your bot a face: in the same **@BotFather** chat send `/setuserpic`, pick your bot, and
   upload `assets/pixi-profile.png` from this kit. Now Pixi is easy to spot in your chat list.
5. Put the token in the bot's `.env` as `TELEGRAM_BOT_TOKEN=<your-bot-token>` — in the file only,
   never in chat.
6. **Single-user guard.** The bot answers **only you**. Leave the owner chat id empty on first
   run, send the bot `/start`, and it replies with your chat id; put that in `.env` (e.g.
   `OWNER_CHAT_ID=<your-chat-id>`) and restart. From then on every update is checked against that
   id and anyone else is refused. This is how a personal bot stays personal.

## Build step B — the conversation loop (one question at a time)

The bot runs a **conversational intake**, exactly the pattern of a conversation agent that
interviews before it works:

1. The student messages the bot with a one-line video idea.
2. The bot **asks clarifying questions one at a time** (at most a few) and waits for each answer —
   it never guesses and never runs off the first message. Enough to fill the brief: the core
   message, the moment/audience, and the mood.
3. When the brief is complete, the bot restates it and moves into production.

Keep the questions minimal and human. The bot is the front door; the machinery behind it is plans
01–02.

## Build step C — the four gates as inline buttons

The bot maps the **same four gates** to **inline keyboard buttons**. At each paid junction it
posts what the student needs to see, plus buttons, and **does not proceed until Approve is
tapped**:

| # | Gate | The bot posts… | Buttons |
|---|---|---|---|
| 1 | Script | the job spec / beats + a cost estimate | Approve · Edit |
| 2 | Identity lock | pre-satisfied by the locked identity — a note only | — |
| 3 | First-clip test | the ONE organic world clip + cost so far (~$0.40) | Approve · Retry |
| 4 | Preview | the assembled sequence + total spend | Approve · Change |

These are the identical gates from plan 02 — only the surface changes from a Claude Code
conversation to chat buttons. **Gate 2 is pre-satisfied** because the identity was already locked
in the core (plan 01) — the character anchor (Path A) or the verified sign (Path B) — so it is
noted at Gate 1, not re-run. The first-clip-test gate stays the critical one: one clip approved
before spending on the rest.

**Structural gate enforcement, not just UI.** Enforce the gates **in code**, below the buttons: a
paid call **asserts its gate flag** before it runs, so no `generate_video` / `generate_speech` /
`generate_music` can fire before its gate was approved — even if the conversation state is somehow
skipped. The buttons are the surface; the assertions are the guarantee.

## Build step D — the production run (same order, same tools)

Between the gates, the bot runs the fixed order from plan 02, calling the engine tools on the
**sequence template**:

1. **Script** — clarify one question at a time, then `analyze` derives a **job spec** on the
   sequence template (world / statement beats fit the idea, always closing on a wordmark beat),
   validated against the spec schema → post the beats + cost estimate → **Gate 1**.
2. **Identity asset** — the identity is already locked; **Gate 2 is pre-satisfied**. On **Path B**
   the wordmark/close is the locked **sign**, a $0 code composite that self-verifies 0 off-brand —
   no `generate_image` for the identity. On **Path A** the identity skill returns the character
   modes the beats need; the closing wordmark/logo is still a code layer. Organic backgrounds, if
   any, via `generate_image`.
3. **Scenes** — each `world` beat is one **organic** engine clip:
   `generate_video(prompt=<world visual + brand tokens verbatim + no-marks/no-sign line>,
   output_path, model="veo-lite", duration_seconds=8, resolution="720p", aspect_ratio="9:16",
   image_path=<organic keyframe or "">)`. Generation buys only the organic world layer; flat
   brand geometry, text, and the sign are code layers (the measured lesson — an image anchor does
   not tame flat brand geometry). Produce **one** clip → post it → **Gate 3** → then the rest.
   Never pass `image_path` on `omni` (it errors).
4. **Voice + music** — `generate_speech(text=<beat narration>, output_path, voice="Kore")` per
   narrated world beat + `generate_music(prompt=<music mood, instrumental texture/tempo words>,
   output_path, length="clip")` (`"song"` past 30s).
5. **Assemble + finish** — the sequence assembly: concat the world clips with the code brand
   layers (captions / statement / wordmark-or-sign close), mix narration over ducked music,
   loudnorm −16 LUFS → post the preview → **Gate 4**. The bot **calls the producer's assembly
   scripts** rather than re-implementing the formula.

Brand tokens are injected verbatim into every prompt, exactly as in plan 02.

## Build step E — idempotent production + the per-job ledger

- **A per-job run folder and ledger.** Each job writes `Operate/<slug>/` with the job spec, all
  media, and a **run-log / ledger** — every paid call (tool · units · est. $), every gate
  (verdict), and the running + final total. The ledger is the job's cost memory.
- **Idempotent production.** Existing paid media on disk is **never regenerated silently**: if a
  world clip / narration / music file for a beat already exists, reuse it. A **Gate-3 Retry** or a
  **Gate-4 Change** that genuinely wants a fresh render passes an **explicit force flag** — the
  only way a paid file is overwritten. A redelivered Telegram update never triggers a second paid
  run.

## Build step F — delivery to the phone

On the Preview approval, the bot **sends the finished video file straight into the chat** (Telegram
video message), so the student gets the result on their phone. Both channels remain available —
the same system is now reachable from Claude Code **and** from the bot.

## Run modes and the one hard rule

- **Local run:** `python <bot>.py` (the PC must stay on).
- **Dry-run rehearsal at $0:** a dry-run env flag stubs the **paid** tools
  (`generate_video` / `generate_speech` / `generate_music`) with already-approved reference media,
  while `analyze` stays real (negligible). Every button, gate, and state is exercised end-to-end
  **without spending a cent** — run this before the first real job.
- **One poller per bot token.** A Telegram bot token allows exactly one poller. If a second
  instance starts against the same token, Telegram returns 409 Conflict and neither works
  reliably — this matters the moment plan 05 puts a copy in the cloud: never run local and cloud
  at the same time.

## Deliverable

A Telegram bot that: takes a request in chat → clarifies one question at a time → runs the same
script → identity → organic scenes → voice + music → assembly order → confirms the same four gates
as inline buttons (Gate 2 pre-satisfied) → delivers the finished on-brand vertical video to the
phone chat. A second client of the engine the student already built — over an MCP stdio client, no
new key, no direct API call, no new way of making media, and no assumption about which identity
path was chosen. It runs locally here; plan 05 takes it to the cloud.
