# מכאן מתחילים — ערכת פיקסי

בתיקייה הזאת יש שני קבצים שחשובים לך:

- `oven.md` — התנור: שיטת STUDIO והמצב החי של הפרויקט.
- `pixi.md` — מסמך העולם: כל מה שידוע על פיקסי, כבר ממופה.

**מה עושים:** פותחים את התיקייה הזאת בקלוד קוד, ומדביקים את הפרומפט הבא.

---

```
בתיקייה הזאת יש שני קבצים: oven.md ("התנור") ו-pixi.md (מסמך העולם).

קרא קודם את oven.md — הוא מסביר את שיטת STUDIO ואיך עובדים איתה, והוא ההוראות שלך.
אחר כך קרא את pixi.md — הוא מכיל את כל מה שכבר ידוע על הפרויקט שאני בונה, פיקסי:
עולם יצירת-הווידאו שלי. מערכת דו-ערוצית שנבנית בשלוש שכבות — קודם הליבה בקלוד קוד
(סקיל-זהות שמחזיק זהות קבועה נעולה — דמות או סמל-מותג בקוד — וסוכן-הפקה שמפיק סרטון
לפי סדר-פעולות עם אישור שלי בכל צומת), אחר כך בוט-טלגרם מקומי, ובסוף פריסה לענן
שמריצה אותו גם כשהמחשב כבוי. הכל רץ על כלי-המדיה של המנוע שבניתי ביחידה 1 — לא
קריאות-API ישירות.

אחרי שקראת את שניהם:
1. צור את תת-התיקיות של הסטודיו: Scout, Target, Unify, Design, Index, Operate —
   ורשום ב"מפת התיקייה" שבתנור מה תפקיד כל אחת.
2. מלא את התנור ממסמך העולם: העבר לתוך משבצות התחנות שבתנור את מה שכבר ידוע מ-pixi.md.
3. אמור לי איפה הפרויקט עומד: מה כבר מלא, מה חסר, ומה הצעד הבא. רוב הדברים כאן כבר
   סגורים — מה שבאמת פתוח לדיוק הוא הזהות של הדמות ושפת-המותג של הסרטון (תחנה 4):
   הריאיון שמנסח את מפרט-הזהות, ובחירת הדפוס לפי מודל-הווידאו.

מכאן והלאה אתה המלווה של הפרויקט: בכל פעם שאני חוזר, קרא קודם את התנור, אמור לי איפה
אנחנו, והוֹבל אותי לשלב הבא — קודם לסגור איתי את הזהות שלי (דמות או סמל) ואת שפת-המותג, ואז
להפקה לפי התוכניות המפורטות שבתיקיית plans/. מסוֹר לי תוכנית אחת בכל פעם, לפי הסדר,
וחכה לי ביניהן. אחרי כל עבודה — עדכן את התנור.

תסביר מה הבנת ותחכה לאישור כדי להמשיך.
```

או, אותו פרומפט באנגלית:

```
This folder has two files: oven.md ("the oven") and pixi.md (the world document).

Read oven.md first — it explains the STUDIO method and how to work with it, and it is
your instructions. Then read pixi.md — it holds everything already known about the project
I am building, Pixi: my video-creation world. A dual-channel system built in three layers —
first the core in Claude Code (an identity skill holding a fixed locked identity — a character
or a brand sign built in code — and a production agent that produces a video by a fixed order
of operations with my approval at every junction), then a local Telegram bot, and finally a
cloud deploy that runs it even when my computer is off. Everything rides on the media tools of
the engine I built in Unit 1 — not direct API calls.

After you have read both:
1. Create the studio subfolders: Scout, Target, Unify, Design, Index, Operate — and record
   in the "folder map" in the oven what each one is for.
2. Fill the oven from the world document: move what is already known from pixi.md into the
   station slots in the oven.
3. Tell me where the project stands: what is already filled, what is missing, and what the
   next step is. Most things here are already settled — what is genuinely open for
   refinement is my identity (a character or a brand sign) and the video's brand language
   (station 4): the path choice, the interview or the sign-from-logo that locks the identity,
   and the pattern choice that follows the video model.

From here on you are the project's companion: every time I come back, read the oven first,
tell me where we are, and lead me to the next step — first to close the character's identity
and the brand language with me, then to production per the detailed plans in the plans/
folder. Hand me one plan at a time, in order, and wait for me between them. After every
piece of work — update the oven.

Explain what you understood and wait for approval to continue.
```
