# Plan 00 — Overview: the Pixi architecture, order, gates, and engine standard

**Read this before any other plan.** It is the map; plans 01–05 are the build steps. This
plan builds nothing — it fixes the rules every later plan obeys.

Pixi is a **dual-channel video-creation system**, built across **three layers**. The student
already built the media engine in Unit 1; Pixi assembles two components on top of it, then a
home layer, then a cloud layer:

- **Core (built in class, in Claude Code):**
  1. an **identity skill** — a fixed identity with a locked identity asset (plan 01). The identity
     forks: **Path A a character** (interview → spec → candidates → anchor lock) or **Path B a
     brand sign** (composed in code from the student's own logo, pixel-exact, never generated).
     The student chooses one; downstream reads "the identity asset" whichever path built it.
  2. a **production agent** — produces a video by a fixed order of operations, with approval
     gates in conversation (plan 02); the first end-to-end run is the demo mission (plan 03).
- **Home layer (built at home, its own window):** a **Telegram bot** — a second client of the
  same engine, conversational, with the same gates rendered as inline buttons, delivering to the
  phone chat, running locally (plan 04).
- **Cloud layer (deployed at home):** the same bot packed into a Docker image and deployed to
  Railway, so it runs 24/7 with the PC off (plan 05).

The layer story in one line: **core in class ← bot at home (plan 04) ← deploy to the cloud
(plan 05).**

## The engine standard (non-negotiable — applies to every plan)

- **All media goes through the engine `gemini-engine`.** Never call the Gemini API directly,
  never open a raw HTTP request to a model. Every image, video, speech, and music operation
  is a call to one of the engine's registered tools, by the exact signature below.
- **The key is already in the engine.** The Gemini API key lives only in the engine's `.env`
  (`GEMINI_API_KEY`), pasted there by the student in Unit 1. **Do not re-request it, do not
  echo it, do not read `.env` back.** Any component that needs media reaches it through the
  engine's tool layer, which loads that key itself.
- **The engine is the single wrapper around media.** In Claude Code the tools are called as
  MCP tools (host = Claude Code, the engine is registered at user scope, available in every
  project). The bot in plan 04 reaches the SAME tool functions from its own process — same
  signatures, same key — so it is a second client, not a second engine.
- **The engine returns JPEG.** `generate_image` returns a JPEG saved as `.jpg` (the engine
  normalises the extension) and never returns a transparent background. This is the engine's
  verified standard — not a claim about what the underlying model accepts on every request.
  Always ask for `.jpg`. When a transparent asset or an exact-color mark is needed, make it
  **locally in code**, not from the engine (see plan 01 mode B, plan 02).

### The six engine tools (from the engine contract — match names and signatures exactly)

| Tool | Signature | Returns | Model | Verified cost |
|---|---|---|---|---|
| `transcribe` | `transcribe(audio_path: str, language: str = "Hebrew") -> str` | transcript text | gemini-3.5-flash | ~$0.003 / audio minute |
| `analyze` | `analyze(text: str, instruction: str = "Summarize the following text.") -> str` | analysis text | gemini-3.5-flash | negligible |
| `generate_image` | `generate_image(prompt: str, output_path: str, resolution: str = "1K", aspect_ratio: str = "1:1", input_image_path: str = "") -> str` | saved JPEG path (`.jpg`) | gemini-3.1-flash-image | $0.045 (0.5K) · $0.067 (1K) · $0.101 (2K) · $0.151 (4K) |
| `generate_video` | `generate_video(prompt: str, output_path: str, model: str = "veo-lite", duration_seconds: int = 8, resolution: str = "720p", aspect_ratio: str = "16:9", image_path: str = "") -> str` | saved MP4 path | veo-3.1-lite-generate-preview (default) · gemini-omni-flash-preview (`model="omni"`) | Veo Lite: $0.05/s @720p, $0.08/s @1080p (8s = $0.40) · Omni: ~$0.10/s |
| `generate_speech` | `generate_speech(text: str, output_path: str, voice: str = "Kore") -> str` | saved WAV path (24 kHz, 16-bit mono) | gemini-3.1-flash-tts-preview | a few cents per short passage |
| `generate_music` | `generate_music(prompt: str, output_path: str, length: str = "clip") -> str` | saved MP3 path | lyria-3-clip-preview (30s) · lyria-3-pro-preview (`length="song"`) | $0.04 / clip · $0.08 / song |

Both `generate_image` and `generate_video` carry an **optional image input** (default `""`):
`generate_image`'s `input_image_path` feeds a local image to edit / transform (image-to-image),
and `generate_video`'s `image_path` feeds a local first-frame anchor (veo path only; on
`model="omni"` an image errors with a clear "not supported on omni yet"). Both are backward
compatible — empty means the behavior is identical to today's text-only call. See the identity
lock below and the scene pattern in plan 02 for how Pixi uses them.

Pixi uses five of the six: `analyze`, `generate_image`, `generate_video`, `generate_speech`,
`generate_music`. (`transcribe` is not part of the video-production flow.) Assembly is done
locally with **ffmpeg**, which is already installed — it is not an engine tool and costs $0.

## The production order (fixed — plan 02 builds it, plan 03 runs it once)

Script → identity + stills → scenes → voice + music → assemble. The order is dependency-driven:
the identity asset and backgrounds are built **before** the scenes, because a scene prompt leans
on them; voice and music are built from the approved script; assembly is last.

| # | Stage | Engine tool | Produces |
|---|---|---|---|
| 1 | Script | `analyze` | a job spec — beats broken out of the brief |
| 2 | Identity + stills | `generate_image` / code | the identity asset (character render or code sign), organic backgrounds |
| 3 | Scenes | `generate_video` | the organic world clips |
| 4 | Voice + music | `generate_speech` + `generate_music` | narration track, music bed |
| 5 | Assemble + finish | ffmpeg + code layers (local) | one finished video file |

## The scene doctrine (measured — every plan honors it)

`image_path` anchors **organic** content excellently (a clip opened on a code keyframe at ~0.5%
pixel difference and held), but on **flat brand geometry the engine invents volume and shadow** —
flat 2D shapes came back as 3D cubes with cast shadows, even in production, even from a clean
keyframe. So: **engine video = organic world / b-roll only** (keyframe-anchored where a
composition anchor helps); **flat brand geometry, text, captions, and the identity sign are built
AND animated in code**; the hybrid is an **engine world clip + code brand layers, composited
locally**. Measured engine limits to respect where a prompt is built: neither media tool preserves
object **count**; motion prompts are followed **weakly** (the keyframe controls composition far
better than the prompt controls motion); chained image-to-image **compounds colour drift** — use
one pass from a code-built source.

## The sequence formula (the recommended production shape)

Plan 02's recommended pattern is a **job-spec-driven sequence** with a fixed beat vocabulary and a
flexible count: one or more **`world`** beats (organic engine clips + code captions) + an optional
**`statement`** beat (code text reveal) + **always a closing `wordmark`** beat (the student's
wordmark/logo, in code). The beat count flexes per idea; **the close is fixed**. `analyze` writes
the spec at stage 1 and the student approves it with a **cost estimate** at Gate 1. Typical cost:
~$0.40 per world beat + ~$0.01 per narration line + ~$0.04 music; the reference shape is a ~3-part,
~14s vertical video. Plan 03 runs it once.

## The four gates (every channel — plan 02 in conversation, plan 04 as buttons)

A gate is a hard STOP: show the student, wait for explicit approval, and only then spend.

| # | Gate | What is approved |
|---|---|---|
| 1 | Script | the job spec / beats and the cost estimate — before any spend |
| 2 | Identity lock | the identity asset (character anchor + spec, or the verified sign) — before it enters production |
| 3 | First-clip test | **one** world clip — before generating the rest |
| 4 | Preview | the assembled video — before finish and save |

The first-clip-test gate is the critical one: one test slice before full production, always. In
plan 04 (the bot) Gate 2 is **pre-satisfied** by the identity already locked in the core.

## Default format

**Vertical 9:16** (the social/reels orientation). 16:9 stays an available choice; per-second
pricing means the aspect ratio does not change cost. Default video model is `veo-lite`; `omni`
is the option (it changes which identity pattern applies — see plan 02, station 4 of pixi.md).

## Identity lock — a constraint every plan honors (both paths)

The identity is frozen into concrete files and every downstream plan reads **those files**, never
a re-derivation — whichever path built them (plan 01):

- **Path A (a character):** locked by the **verbatim word spec** (always injected) + the **saved
  anchor still** + **regenerate-on-drift**. The engine's optional image inputs mean the anchor can
  **also** be fed as a visual reference — image-to-image to reproduce the identity, or a
  first-frame keyframe to anchor an organic clip — but the word spec stays the canon.
- **Path B (a sign):** locked by a **code recipe** — the sign is taken byte-faithful from the
  student's own logo and redrawn by a code sprite that **forces the exact brand RGB at every
  size**, verified **0 off-brand pixels at full size and after resize**. A sign cannot drift
  because it is never sent to a model.

One boundary is absolute for both paths: the **sign / wordmark / logo is composed in code, never
generated and never model-edited, never mirrored.** Image input opens no back door — a keyframe or
reference goes in **sign-free**, and the sign is overlaid in code afterward (see plan 02, "Right
tool for precision"). On Path A the closing wordmark/logo is code even though the character render
is generated.

## Who builds what

- Plans **01** and **02** are handed to the student's **agent-builder meta-agent** (the
  course's agent that builds agents and skills). The student gives it the plan; it builds the
  personal skill / agent. No code is written by hand; no ready-made skill is delivered.
- Plan **03** runs the first end-to-end production in Claude Code.
- Plan **04** builds the Telegram bot (local) in its own clean build window.
- Plan **05** deploys that bot to Railway (the cloud layer).
