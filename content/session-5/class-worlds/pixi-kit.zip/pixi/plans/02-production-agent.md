# Plan 02 — The production agent (the soul)

**This plan is handed to the student's agent-builder meta-agent.** The student gives it this
plan; it builds the personal production agent. No hand-written code; each student ends up with
their own producer.

Read plan 00 first. Every media call is an engine tool on `gemini-engine`, by its exact
signature. No direct API calls. The key is already in the engine — never request it.

## What the agent is

The agent is the **producer**. The student gives it one sentence — "make me a video about X" —
and it drives the whole chain: writes a script, produces the identity asset and any organic
stills, produces scenes, produces voice and music, and assembles one finished video. It **calls
the identity skill** (plan 01) for the identity asset — a character render on Path A, or a
code-composited sign on Path B — **consumes the brand studio** for every on-brand pixel, and
**stops at four gates** so the student approves before money is spent.

Default output: **vertical 9:16**, model `veo-lite`. 16:9 is an available choice; `omni` is
the model option and changes which pattern applies (see "Where the identity lives").

## The fixed order of operations

Script → stills → scenes → voice + music → assemble. The order is dependency-driven and no
stage is skipped. The identity asset and backgrounds are produced **before** the scenes, because
a scene prompt leans on them.

---

### Brand consumption — verbatim token injection (applies to every media prompt)

The agent reads the brand studio's values once at the start of a run — colors (literal hex),
font name, visual language, tone — and **injects them verbatim into every prompt** it sends to
`generate_image`, `generate_video`, and `generate_music`. This is the single mechanism that
makes every frame on-brand. When the agent reads brand values it **reproduces** them into the
prompt — it does not re-describe them. If the brand studio is missing, the agent stops and says
so — it does not invent a look.

**Only two legal moves for moving brand canon** (never a third):

1. **Point at the source and inject verbatim** — read the brand-studio source files at runtime
   and inject their exact values into the prompt string; no local re-expression.
2. **Copy with diff-verify** — if a value must be copied into a local file first, the copy is
   byte-faithful and diff-verified against the source before use.

**Forbidden:** copying canon "in your own words" — summarizing, restructuring, or paraphrasing
it into a working folder. A summarizing copy silently drops constraints (this kit's first run
lost a scene slot, a JPEG note, and a fill constraint exactly this way).

**The injection rule is narrow, so it never contradicts the canon block it must inject.** Never
**replace** a brand value — a hex, a font-family name — with a word. A value **may be
accompanied** by a short descriptor (e.g. a hex followed by a color word); the injected canon
block always wins verbatim. The ban is on substitution, not on description.

---

### The scene doctrine — what the engine earns its cost on (measured, corrected)

This corrects the earlier "keyframe-anchor the flat brand geometry" instruction with what the
live runs actually measured. Two facts, both measured on the real engine:

- **`image_path` anchors ORGANIC content excellently.** A `generate_video` call opened on a
  code-built keyframe at a **mean pixel difference of 0.5%** (h264 noise only) and stayed on that
  composition for the full clip. Put every layout decision in the keyframe; the text prompt only
  needs to describe the *character* of the motion.
- **On FLAT BRAND GEOMETRY the engine still invents volume and shadow — even in production.**
  Flat 2D brand shapes came back as **3D cubes with cast shadows** the moment the engine animated
  them, and this held **even when fed a clean flat keyframe** in a real production run. The engine
  cannot be trusted to keep flat brand geometry flat.

So the doctrine is:

- **Engine video = organic world / b-roll only** — scenes, environments, textures the code
  cannot make. Keyframe-anchor it (`image_path`) where a composition anchor helps.
- **Flat brand geometry, text, captions, and the identity sign = built AND ANIMATED in code.**
  Never ask the engine to move a flat brand shape.
- **The hybrid formula:** an **engine world clip** + **code brand layers**, **composited
  locally** (ffmpeg / a browser render). This is what the recommended sequence below realizes.

**Measured engine limits — state these where a prompt is constructed:**

- **Neither media tool preserves object COUNT.** Six squares in came back as nine, on both
  `generate_image` (image-to-image) and `generate_video`. Style, palette, background, and
  composition survive; exact quantities do not. Build counted layouts in code.
- **Motion prompts are followed weakly.** "No rotation, slide inward and lock" produced rotation
  and motion blur. The **keyframe controls composition far better than the prompt controls
  motion** — treat motion wording as a suggestion.
- **Chained image-to-image compounds colour drift.** One fresh generation drifted a few units
  off the brand fill; one image-to-image pass roughly tripled it toward the tolerance edge. Use
  **one pass from a code-built source** — never a chain.

### Right tool for precision — code builds exact marks, type, and geometry

Never spend `generate_image` on a **mark/sign/logo, typography, or a strict geometric
composition**. Code builds those **exactly and for free** — a generated image only approximates
them, at cost, and can never be trusted for exact brand color or precise geometry. Generation
earns its cost **only on organic imagery code cannot make** — b-roll, scenes, characters.
Title/closing cards, captions, statement text, and any sign overlay are therefore composited in
code, not generated.

**The sign is composed in code — never generated, never model-edited. Image input opens no back
door.** The optional image inputs (`input_image_path` on `generate_image`, `image_path` on
`generate_video`) let a code-built keyframe or an organic still ride in as a visual reference —
but they never make a sign reproducible by a model. Keyframes and references go in **sign-free**,
and the sign is overlaid in code **after** the model step. A fed reference reproduces organic
content and layout; the sign is always the last, code-only layer. (On Path A, the same rule
applies to the closing wordmark/logo, which is code even though the character itself is generated.)

**Fill re-force after a code resize.** When a mark/sign/logo is resized in code, resampling
(LANCZOS and friends) drifts the fill color at every anti-aliased edge — a silent off-brand ring.
After any resize, **re-force the exact brand RGB and keep only the resampled alpha:**

```python
def mark_at(h):
    m = mark.resize((int(mark.width * h / mark.height), h), Image.LANCZOS)
    alpha = m.split()[3]                        # keep only the resampled alpha
    forced = Image.new("RGBA", m.size, BRAND_RGB + (0,))  # exact brand fill
    forced.putalpha(alpha)
    return forced
```

`BRAND_RGB` is the student's exact brand color as an `(r, g, b)` tuple. This preserves the
anti-aliased edge while guaranteeing the fill is exact — the naive `resize(...)` alone leaves a
few thousand edge pixels off-color. (Path B's identity skill already owns this sprite; the agent
reuses it. Or displays a code layer at native size so nothing resamples.)

---

### Stage 1 — Script — **Gate 1: Script**

- Input: the student's one-sentence brief (+ any details from a short clarifying exchange).
- Tool: `analyze(text, instruction)` — pass the brief as `text`, and an `instruction` that
  asks for a beat breakdown for a short vertical video on the **sequence template** below: one or
  more world beats (each with a one-line visual and a one-line narration line), an optional
  statement beat, and a closing wordmark beat, plus a music mood.
- Output: the beats + a **cost estimate** for the run (see the sequence formula), written to the
  run folder.
- **Gate: show the beats, the plan, and the estimate; wait for explicit approval.** Nothing is
  spent yet (`analyze` is negligible). The student can edit beats before approving.

### Stage 2 — Identity asset + stills — (feeds the Identity-lock gate if not yet locked)

- **The identity asset** — call the **identity skill** (plan 01), not `generate_image` directly.
  On **Path A** ask it for the character modes the beats need (opening/closing card, an overlay
  cutout); it reads the frozen `Design/identity-spec.md` + `Design/anchor.jpg` and injects the
  spec verbatim. On **Path B** ask it for the sign composite (a $0 code composite that
  self-verifies 0 off-brand). If the identity is not locked yet, the skill runs its lock now
  (interview+pick on Path A, or take-from-logo+verify on Path B) — that lock **is gate 2
  (Identity lock)**.
- **Backgrounds / organic stills** — one per body beat where the world beat is keyframe-anchored
  on a still; storyboarded from the beats so they carry the story. On-brand environment/scene,
  **no text, no sign**. `generate_image`, 9:16, $0.067 per 1K image.
- **Title / caption / statement cards** — text is **not** rendered by the image model; it is laid
  on later in code (assembly), so Hebrew stays correct and RTL.
- Track the count in the run log.

**Hard prompt-order rule (stages 2 and 3).** Every prompt **opens with the concrete
subject-and-scene**, and the brand/style block **follows and qualifies it**. A prompt that
opens with the style block inverts figure and ground — the style becomes the subject and the
scene loses (measured: a request for dark blocks with one yellow accent came back as a yellow
field with the blocks cut out of it). Subject first, style second — always.

### Stage 3 — Scenes — **Gate 3: First-clip test**

- Tool: `generate_video(prompt, output_path, model="veo-lite", duration_seconds=8,
  resolution="720p", aspect_ratio="9:16", image_path=<keyframe or "">)`. Pass `model="omni"` only
  if the student chose omni (and never pass `image_path` on omni — it errors there).
- **Each scene is an ORGANIC world clip.** Per the doctrine above, generation buys only the
  organic world layer; flat brand geometry, text, and the sign are code layers composited
  afterward. The prompt follows the prompt-order rule — the beat's concrete visual/scene first,
  then the brand tokens verbatim (qualifying it), then a **no-marks / no-sign line** so the frame
  is left clear for the code composite.
- **Anchoring, when it helps.** For an organic world beat, `image_path` may carry a code-built
  or generated **organic** keyframe to fix the composition (it anchors organic content at ~0.5%
  drift). Leave `image_path` empty for a plain text-only clip.
- **The flat-geometry keyframe pattern is available but NOT the default.** For the rare case
  where a flat brand-geometry motion is genuinely wanted: (1) code-build an exact on-brand
  keyframe — flat geometry, the exact brand palette, the correct target dimensions (720×1280 for
  9:16 @720p so nothing crops), **no sign in the frame**; (2) animate FROM it via `image_path`
  while the prompt still describes the flat 2D motion; (3) composite the sign in code afterward.
  Know that the engine may still invent volume/shadow here (measured) — prefer building AND
  animating flat brand geometry entirely in code.
- **Produce ONE clip first — the test slice — and STOP.** This is gate 3: show the single
  clip, show cost so far, wait for approval. One `veo-lite` 8s clip @720p = $0.40. Only after
  approval, produce the remaining scenes.
- `duration_seconds` accepts "4" / "6" / "8" on Veo. Omni generates up to ~10s and ignores
  `duration_seconds`.

**Where the identity lives (follows path + model choice):**
- **Path A on `veo-lite` (default):** the character appears as **reproduced stills** (opening/
  closing cards, overlay cutouts from the identity skill) over **on-brand organic b-roll**, and
  the narration is the character's voice. Stills reproduce the identity far better than video.
- **Path A on `omni` (option):** the character **may live inside the clips** as a speaking/acting
  figure, with the identity spec injected into the clip prompt, plus the narration. A first-class
  pattern for omni, not a fallback.
- **Path B (any model):** the sign is a **code composite / overlay** over organic b-roll; the
  narration is the voice. Omni only buys longer in-scene motion, never a drawn sign.

### Stage 4 — Voice + music

- **Narration** — `generate_speech(text, output_path, voice="Kore")`. Pass each beat's
  narration line as `text`; Hebrew is supported. Output is a WAV per line (or one combined
  pass). Cost: a few cents per short passage (~$0.01 per line). `voice` may be changed to any of
  the engine's prebuilt voices.
- **Music** — `generate_music(prompt, output_path, length="clip")`. Prompt = the script's
  music mood + brand tone, injected verbatim, and **kept to instrumental texture / tempo words
  only** (a derived prompt can be refused; see plan 05). A clip is 30s ($0.04); `length="song"`
  gives a full song ($0.08) for videos longer than 30s.

### Stage 5 — Assemble + finish — **Gate 4: Preview** — (ffmpeg / code layers, local, $0)

Assembly is local — not an engine tool, no spend. The world clips are concatenated with the code
brand layers (captions, statement, the wordmark/sign close) in beat order, the narration is mixed
over ducked music, loudness is normalized (loudnorm, target −16 LUFS), and the result is muxed.
See plan 03 for the exact ffmpeg audio-mix commands. Then:

1. Optional: burn a Hebrew caption. Because Hebrew is RTL, if captions are burned the agent
   must **eyeball the result** — never assume it rendered correctly. (Captions in the sequence
   template are code layers, not a burned SRT.)
2. Produce a **preview** and **STOP** — this is gate 4: the student watches the assembled
   video end-to-end and sees total spend, before finish and save.
3. On approval, write the final file to the run folder.

---

## The sequence formula — the recommended production pattern

The proven shape from the live runs is a **job-spec-driven sequence**: a flexible-beat video
whose building-block vocabulary is fixed but whose **count and content flex per idea**, always
closing on the student's wordmark/logo. This is the recommended realization of stages 2–5; the
five-stage / four-gate protocol above still governs **when** things run and **what** they cost.

**The building blocks (the beat vocabulary):**

- **`world`** — one **organic engine clip** (`generate_video`, veo-lite, organic content,
  drift-tolerant) + an optional narration line shown as **synced captions (code layer)**. Each
  world beat is one 8s clip trimmed to length — one **$0.40** spend, each waiting on its gate.
- **`statement`** — a key line (or lines) revealed on the brand background in code — an
  animated text reveal (opacity + translateY), a **code layer**, $0.
- **`wordmark`** — the student's **wordmark / logo**, built in code and **always the final
  beat**. On Path B this is the locked sign; on Path A it is the student's logo (still code, not
  the generated character). The close is **fixed** — every sequence ends here.

**Flexible count, fixed close.** A job is a list of beats — **one or more** world beats, an
**optional** statement, and **always** a closing wordmark. Fit the beat count to the idea; do not
force extra beats. The reference shape from the live run is a **~3-part, ~14s vertical** video
(one world beat + statement + wordmark close).

**Job-spec-driven.** `analyze` derives a **job spec** (the beat list + per-beat content + music
mood) at stage 1; the student approves it at Gate 1 **with a cost estimate**. The spec is the
contract the rest of the run reads — the agent never re-improvises the formula mid-run.

**The measured lesson this shape encodes:** `image_path` does NOT tame flat brand geometry — the
engine invents 3D/shadow the moment it moves a flat shape. So generation earns its cost only on
**organic world/b-roll**; flat geometry, text, captions, and the sign are code. The flat-geometry
keyframe pattern (stage 3) stays available for the rare case, but it is not the default.

**Typical cost (per the engine contract):** ~**$0.40 per world beat** + ~**$0.01 per narration
line** + ~**$0.04 music** (statement and wordmark beats are code layers, $0). A one-world-beat
trial ≈ **$0.45**; add **$0.067** if a world beat is keyframe-anchored on a generated organic
still. Present the estimate at Gate 1.

## The four gates (summary)

| # | Gate | Where in this plan |
|---|---|---|
| 1 | Script | end of stage 1 (with the cost estimate) |
| 2 | Identity lock | when the identity locks (via the identity skill, stage 2) |
| 3 | First-clip test | one clip in stage 3, before the rest |
| 4 | Preview | assembled video in stage 5, before finish/save |

Two stops matter most: **identity lock** (no scenes before the identity is approved) and
**first-clip test** (one clip approved before spending on the rest).

## Run log

Keep a run log in the run folder: model-choice, every paid call (tool, units, est. $), every
gate (verdict), and the running + final total. The run log is the system's cost memory.

## Deliverable

A personal production agent that: takes a one-line brief → `analyze` for a job spec + cost
estimate (gate) → identity skill + `generate_image` for the identity asset and any organic
stills (identity-lock gate) → `generate_video` for organic scenes (first-clip gate) →
`generate_speech` + `generate_music` for audio → code layers + ffmpeg to assemble (preview gate)
→ a finished on-brand vertical video, closing on the student's wordmark, saved locally. Brand
tokens injected verbatim throughout. Built for this student.
