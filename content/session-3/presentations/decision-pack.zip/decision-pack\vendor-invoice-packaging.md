# INVOICE

**PackRight Shipping Materials Ltd.**
Invoice #PR-77310
Date: September 2

Bill to: SporaBox (Fulfillment Operations)

| Item | Qty | Unit price | Total |
|---|---|---|---|
| Corrugated mailer box, medium | 2000 | $0.62 | $1,240.00 |
| Kraft void-fill paper, roll | 30 | $14.00 | $420.00 |
| Branded packing tape, 100m roll | 48 | $3.25 | $156.00 |
| Thermal shipping labels, box of 500 | 12 | $9.00 | $108.00 |

Subtotal: $1,924.00
Tax: $346.32
**Total due: $2,270.32**

Payment terms: net 30. Please remit to the account on file.
Thank you for your business.
