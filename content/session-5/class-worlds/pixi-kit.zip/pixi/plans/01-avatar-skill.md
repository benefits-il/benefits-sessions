# Plan 01 — The identity skill (two paths: a character or a sign)

**This plan is handed to the student's agent-builder meta-agent** — the course's agent whose
whole job is to build other agents and skills. The student gives it this plan; it builds the
personal identity skill. Nothing here is written by hand, and no ready-made skill is delivered:
each student ends up with their own identity, built for them.

Read plan 00 first. Every image call in this plan is `generate_image` on the engine
`gemini-engine`, by its exact signature. No direct API calls. The key is already in the
engine — never request it.

## The identity fork — choose the path first

Pixi's identity has **two first-class paths**, and the student picks one **at the start**,
before anything is built. Both produce the same kind of thing: a **locked identity asset** that
every downstream plan (02, 03, 04) reads off disk and reproduces, never redesigns.

- **Path A — a character.** A person-like avatar, mascot, or stylized figure, defined once in
  words and locked to a chosen render. Built through an interview → draft spec → candidate
  renders → lock. This is an **avatar skill**.
- **Path B — a sign.** A brand mark or wordmark, composed **in code** from the student's own
  logo — pixel-exact, never generated, never model-edited. Built by copying the student's logo
  faithfully and forcing the exact brand color in code. This is a **sign skill** instead of an
  avatar skill.

Choose by what the brand actually is. If the brand lives in a **face/figure**, take Path A. If
the brand lives in a **mark/logo** (a symbol, a wordmark), take Path B — a sign is sharper,
free, and pixel-exact, and it never drifts. Ask the student once, up front, and build only the
chosen path.

## Shared for both paths (these hold whichever path you build)

- **The locked-artifact principle.** The identity is frozen into **concrete files on disk**, and
  every downstream consumer reads **those files**, never the skill's internal state and never a
  re-derivation. Name the files once; forbid any consumer from re-deriving them. The identity
  skill's frozen state is its `references/` — loaded verbatim, never re-summarized.
- **Verbatim injection.** Whatever text describes the identity (the character word-spec, or the
  sign's brand values) is injected into prompts as **literal strings**, never paraphrased.
- **Two legal moves for brand canon** (never a third):
  1. **Point at the source and inject verbatim.** Read the student's brand-studio source files
     at build time and copy the exact values — hex strings, font-family name, visual-language
     phrases — into the spec as literal strings. No local re-expression.
  2. **Copy with diff-verify.** If a value genuinely must be duplicated into a local file, the
     copy is **byte-faithful** and verified by diffing it against the source before use.
  **Forbidden — the third move:** copying canon "in your own words" — summarizing, restyling,
  or restructuring it. A summarizing copy silently drops constraints (a value, a format note, a
  scene slot); that is exactly how this kit failed its first run. Duplicate the values; never
  re-describe them.
- **The drift rules** (identical for both paths):
  - **Identity drift → regenerate, never retouch.** Any output that changes the identity — a
    character's face/build/wardrobe/style, or a sign that came back altered — is **discarded and
    regenerated**, not "improved" or patched. (A sign is never sent to a model at all, so it
    cannot drift — see Path B; the rule bites on Path A renders and on any generated background.)
  - **Brand-color — two standards, and this matters pedagogically.** Hold each path to its own
    standard, never a code-grade check on a generated image:
    - **Code-built output** (a sign, a card, type composited in code): held to the **exact**
      brand values. Code has no excuse — the fill is placed, not guessed.
    - **Generated output** (`generate_image`): held to a **wide tolerance** (about ±12 per
      channel fits the measured data), verified by eye, not by an exact match. The engine
      returns JPEG, and JPEG compression alone shifts a flat fill a few units per channel —
      before the model's own approximation. **Generation is not the tool for exact brand color.**
  The pedagogical point: a strict per-channel check applied to a generated image fails almost
  always, and a student who sees it fail concludes "generation is broken" — the wrong lesson.
  The right lesson is that exact color comes from code, and generation earns its cost on organic
  imagery where broad tolerance is fine.

---

# Path A — the character (avatar skill)

A skill that **holds one fixed character and reproduces it — never redesigns it.** Not "a new
picture every time" but one defined character, returned in different usage modes. It carries
two things:

1. a **locked identity spec** — a precise word description (who the character is, how they
   look, build, wardrobe, tone), detailed enough to be reproduced from words alone;
2. a **saved anchor image** — one chosen render kept as the reference-of-truth.

Consistency comes from the **verbatim identity spec** injected into every prompt AND, now, from
the **anchor fed as an image reference**: `generate_image`'s optional `input_image_path` can
take the locked anchor to reproduce the identity (image-to-image) when that helps. The word spec
stays the canon and is always injected; the anchor reference reinforces it. The drift check is
unchanged — eyeball every result against the anchor and **regenerate on any drift**, never
retouch.

## A1 — the identity interview

The skill opens by **interviewing the student**, one question at a time, and waits for each
answer (it never invents answers):

1. Who is the character — a person-like avatar, a mascot, a stylized figure?
2. Face and build — hair, facial features, body type, distinguishing marks.
3. Wardrobe — default outfit; an alternate if wanted.
4. Style — the illustration language (this must agree with the brand studio from Unit 1:
   colors, and the overall visual language).
5. Tone and personality — the vibe the character projects.

If the student has a reference they like (a poster, a style, a character that speaks to them),
take it as the **starting point of the interview** — describe it in words so it shapes the spec.
The image the engine later takes as a reference (`input_image_path`) is the student's OWN locked
anchor, not someone else's poster; an external inspiration is authored into words first, never
copied wholesale. If there is no reference, offer a default and let the student refine from there.

From the answers, compose a **draft identity spec**: a single, ordered, literal paragraph
(appearance → build → wardrobe → style → palette from the brand studio → tone), written so it
can be pasted verbatim into an image prompt. Keep it free of vague adjectives with no anchor
("nice", "cool") — every trait must be concrete. Move brand canon into the spec by the **two
legal moves** above, never the third.

## A2 — candidate generation

Generate **2–4 candidate renders** of the character from the draft spec:

- Tool: `generate_image(prompt, output_path, resolution="1K", aspect_ratio="9:16")`.
- Prompt = the draft identity spec + a neutral pose/framing + the brand palette and visual
  language injected **verbatim** (literal hex values and font/style words from the brand
  studio). No text, letters, or numbers rendered in the image.
- Save each candidate to the skill's `Design/` working area with a clear name.
- Cost: $0.067 per 1K image → ~$0.13–0.27 for 2–4 candidates.

Show the candidates to the student.

## A3 — pick and lock — **Gate: Identity lock**

The student **picks the candidate that feels right**. On pick, freeze the character as **two
concrete saved files** — these are the durable artifacts every downstream consumer reads:

- `Design/anchor.jpg` — the chosen render, kept as the anchor image (the reference-of-truth).
  The engine returns JPEG and saves as `.jpg`; the anchor is that `.jpg` file.
- `Design/identity-spec.md` — the frozen identity spec: the exact verbatim word-spec that will
  be injected into every prompt from now on.
- Record in the oven (station 4 / the Design subfolder) that the identity is locked, with both
  paths.

This is gate 2 of the four gates: nothing downstream uses the character until this lock is
approved.

## A4 — the usage modes

The skill returns the locked character in four modes. Every mode injects the frozen identity
spec verbatim, then adds only what the mode needs:

- **A — Pose / expression on the brand background.** A portrait or full-body character in a
  described pose + expression + wardrobe, on the brand canvas. → `generate_image`,
  `aspect_ratio` per use (`9:16` default, `1:1` for an avatar, `16:9` for a banner).
- **B — Transparent cutout** (for overlays on video, posts). The engine's render comes back
  as a **JPEG with a background** — it never returns transparency. So transparency is created
  **only as a local post-process**: run Mode A on a flat, easily-keyed background, then remove
  that background (background removal / keying) in code; the output is a **local transparent
  PNG**, produced by local processing, not by the engine. Keep the largest connected shape;
  drop stray decoration. This is a permitted **local post-process on an already-generated
  image** — the same category as ffmpeg — not a media-generation step; the source image still
  came from `generate_image` as a `.jpg`, and only the local step makes the `.png`.
  Image-to-image does not change this: even when Mode A feeds the anchor via `input_image_path`,
  the engine's output is still a JPEG with a background — the cutout stays a local post-process.
- **C — Character inside a described scene** (for a tutorial or marketing frame). Full-body
  character, on-identity, placed in a described environment, composed with headroom for a
  later caption. → `generate_image` with the scene appended to the spec.
- **D — Prompt-only.** Return the assembled, copy-ready prompt and generate nothing (for when
  no image tool is available, or the student only wants the prompt). Use it as the **free**
  pre-check: confirm the assembled prompt carries the literal hex and font before paying for a
  render.

## A5 — the drift check (runs before any render is called "done")

Compare every render to the anchor: same character, same build, same wardrobe, same style.
**If it drifts, regenerate — do not "improve" or retouch the character.** A render that changes
the face or proportions is discarded, not fixed. Brand-color is held to the split standard in
"Shared for both paths" above.

---

# Path B — the sign (sign skill)

A skill that **holds one fixed sign and reproduces it exactly** — a brand mark or wordmark, built
**in code** from the student's own logo. The sign is **never generated, never model-edited, and
never mirrored.** Where Path A locks a *render*, Path B locks a *code recipe* that redraws the
student's own mark at any size, pixel-exact, in the exact brand color.

## B1 — take the sign from the student's own logo

- The student **already has a logo** (from the brand work in Session 3 / the Unit-1 brand
  studio). The sign is **copied byte-faithful** from that logo source — not redrawn from
  memory, not re-described, not regenerated. Point at the source file and copy it verbatim, or
  copy-with-diff-verify (the two legal moves).
- If the logo source is a color-on-white or otherwise flat raster, recover the shape's coverage
  from the appropriate channel — but the **fill is always re-forced to the exact brand RGB in
  code** (see B2). The student's own file is the single reference-of-truth; nothing about the
  sign is invented.

## B2 — the code sprite: force the exact brand RGB, keep only the alpha

The sign is composed by a small **code sprite** the skill owns. At **every** size it needs, the
sprite forces the exact brand color and keeps only the resampled transparency — so the mark is
pixel-exact at any scale and never carries an off-brand edge:

```python
def sign_at(h):
    m = sign.resize((int(sign.width * h / sign.height), h), Image.LANCZOS)
    alpha = m.split()[3]                          # keep only the resampled alpha
    forced = Image.new("RGBA", m.size, BRAND_RGB + (0,))  # exact brand fill
    forced.putalpha(alpha)
    return forced
```

`BRAND_RGB` is the student's exact brand color as an `(r, g, b)` tuple, read verbatim from the
brand studio. Resampling (LANCZOS and friends) drifts the fill color at every anti-aliased edge
— a silent off-brand ring. Re-forcing the fill after every resize keeps the anti-aliased edge
while guaranteeing the color is exact; the naive `resize(...)` alone leaves thousands of edge
pixels off-color.

## B3 — verify pixel-exact — **Gate: Identity lock**

Lock the sign as concrete files, then prove it before anything downstream uses it:

- `Design/sign.png` (or the composited cutout) + the **sprite script** that redraws it, and
  `Design/identity-spec.md` — the frozen sign spec: the source path, the exact `BRAND_RGB`, the
  build rules, and the boundary "never generated, never model-edited, never mirrored." These are
  the durable artifacts every downstream consumer reads.
- **Verification (the gate):** confirm **0 off-brand pixels at full size AND after a resize** —
  every opaque pixel is exactly `BRAND_RGB`, both at native size and at a scaled size the sprite
  produced. Record the pass in the oven (station 4 / the Design subfolder).

This is gate 2 of the four gates: nothing downstream uses the sign until this lock is approved.
Because the sign is built and verified in code, the interview does not apply here — the lock is a
**verification**, not a pick.

## B4 — the usage modes

The sign returns in code-composited modes; every mode places the exact-color sprite, none sends
the sign to a model:

- **A — Sign card on the brand background.** The sign composited on the brand canvas in code
  ($0). Used for opening / closing cards.
- **B — Transparent cutout for an overlay** (on a clip, a post). The sprite exported as a
  transparent PNG, placed at a fixed corner in assembly — **displayed at native size** so the
  browser/ffmpeg never resamples it (or re-forced by the sprite if a scale is needed). $0.
- **C — Sign over a generated organic still.** The organic still comes from `generate_image`
  (broad-tolerance, on-brand); the sign is composited **on top, in code, after** the model step
  — the still goes to the model **mark-free**. The still costs $0.067; the sign layer is $0.

## B5 — the boundary that never moves

**The sign is composed in code — never generated, never model-edited, never mirrored. Image
input opens no back door.** The engine's optional image inputs (`input_image_path`,
`image_path`) may carry an organic still or a code-built keyframe as a reference — but they
**never** carry the sign. A frame goes to the model **sign-free**, and the sign is the last,
code-only layer composited afterward. Never hand the model a frame containing the sign and
expect it to survive.

---

## What downstream consumes — the identity asset (both paths)

Whichever path was built, plans 02–04 consume the **same contract**: an **identity asset** frozen
into `Design/identity-spec.md` (+ `Design/anchor.jpg` on Path A, or the sign sprite + `sign.png`
on Path B). Downstream:

- The **production agent** (plan 02) reads those files and asks the skill for a mode + a short
  situation, getting back an on-identity asset (or prompt). On Path A that is a reproduced
  character render; on Path B that is a code-composited sign. Either way it never re-derives the
  identity.
- The **Telegram bot** (plan 04) reads the same frozen files off disk.

No downstream plan assumes a character: every reference is to "the identity asset," and the
sequence's closing beat is always the student's **wordmark / logo** built in code regardless of
which identity path was chosen (see plan 02).

## Deliverable

A personal identity skill on the chosen path:
- **Path A** — interviews → drafts a spec → generates candidates via `generate_image` → locks
  the pick as anchor + frozen spec → returns the character in four modes → drift-checks every
  render.
- **Path B** — takes the sign byte-faithful from the student's own logo → builds a code sprite
  that forces the exact brand RGB at every size → verifies 0 off-brand pixels at full size and
  after resize → returns the sign in code-composited modes → never generates, model-edits, or
  mirrors the sign.

Built for this student, holding this student's identity. No hand-written code delivered ready-made;
no shared skill.
