# Plan 03 — First run: the demo mission

Read plan 00 first. This plan runs the **sequence formula once**, end to end, in Claude Code, to
prove the system before building it out. It is the thinnest slice that still produces a real,
on-brand video on the recommended shape.

The demo mission: **one short vertical 9:16 sequence** — the reference shape is a **~3-part, ~14s
video**: one **world** beat (an organic engine clip + narration) + an optional **statement** beat
(code) + a **wordmark** close (code). Every media call is an engine tool on `gemini-engine`, by
its exact signature. No direct API calls. The key is already in the engine.

## Preconditions

- The engine `gemini-engine` is registered and its six tools list in Claude Code.
- The identity skill (plan 01) exists and the identity is locked — the character anchor + frozen
  spec (Path A), or the verified sign + frozen spec (Path B).
- The brand studio (Unit 1) is present, so its tokens can be injected verbatim.
- ffmpeg is installed (it is, from earlier in the course).

## The run — step by step, with cost per step

Work in a run folder (e.g. `Operate/first-run/`). Keep a run log.

### Step 1 — Script → job spec — Gate 1

- Brief: one sentence, e.g. "a short vertical clip introducing my brand."
- Call: `analyze(text=<brief>, instruction=<ask for a job spec on the sequence template: one
  world beat with a visual line + a narration line, an optional statement line, and a closing
  wordmark beat, plus a music mood, for a short 9:16 video>)`.
- **Gate 1: show the beats + the cost estimate, wait for approval.** Cost: negligible
  (`analyze`). The estimate for this trial ≈ **$0.45** (see the total below).

### Step 2 — The identity asset (code or one still)

- **Path B (sign):** the wordmark/close is the locked sign — a **$0 code composite** that
  self-verifies 0 off-brand. No `generate_image` for the identity. If a world beat is anchored on
  an organic still, that still is `generate_image`, $0.067.
- **Path A (character):** ask the identity skill (plan 01, mode A or C) for one on-identity image
  sized `9:16` — under the hood `generate_image(prompt=<frozen spec + brand tokens verbatim +
  pose/scene>, output_path="Operate/first-run/identity.jpg", resolution="1K", aspect_ratio="9:16")`,
  $0.067. The closing wordmark/logo is still a **code layer**, not the generated character.
- (The identity was already locked in plan 01, so **Gate 2 is already satisfied**. If not locked,
  lock it here first — that is Gate 2.)
- **Right tool for precision.** Spend `generate_image` only on organic imagery. Never spend it on
  a sign/logo, on typography, on a statement card, or on a title/closing card: code builds those
  exactly and for free, and a generated version only approximates them at cost.

### Step 3 — One world clip — Gate 3 (first-clip test)

- Call: `generate_video(prompt=<beat visual + brand tokens verbatim + a no-marks/no-sign line>,
  output_path="Operate/first-run/world.mp4", model="veo-lite", duration_seconds=8,
  resolution="720p", aspect_ratio="9:16", image_path=<organic keyframe or "">)`.
- **Organic content only.** The world clip is organic b-roll — generation is not asked to move
  flat brand geometry (measured: it invents 3D cubes with shadows for flat 2D shapes, even from a
  keyframe). `image_path` may carry a code-built or generated **organic** keyframe to fix the
  composition (it anchors organic content at ~0.5% drift); leave it empty for a plain text-only
  clip. (`image_path` is a veo-only anchor; it errors on `model="omni"`.)
- **Cost: $0.05/s × 8s @720p = $0.40.**
- **Gate 3: this single clip is the test slice — watch it, show cost so far, wait for
  approval** before producing any more world beats. (In the reference shape there is one world
  beat, so this gate also confirms the clip is good enough to finish.)

### Step 4 — Narration + music

- Narration: `generate_speech(text=<the world beat's narration line, Hebrew ok>,
  output_path="Operate/first-run/vo.wav", voice="Kore")`. **Cost: ~$0.01.**
- Music: `generate_music(prompt=<script music mood + brand tone, verbatim; instrumental texture /
  tempo words only>, output_path="Operate/first-run/music.mp3", length="clip")`. **Cost: $0.04**
  (a 30s clip covers a ~14s video).

### Step 5 — Assemble the sequence + finish — Gate 4 (preview) — $0

All local; no engine tool, no spend. The sequence is the world clip + code brand layers (synced
captions, the optional statement reveal, the wordmark/sign close) concatenated in beat order,
with narration mixed over ducked music, loudnorm −16 LUFS, then muxed. The code layers (captions,
statement, wordmark) are built in a browser render or ffmpeg drawtext — **never** by the image
model, so text and the sign stay exact and Hebrew stays RTL-correct.

The audio finish is the same ffmpeg shape whether one clip or several:

```
# 1) Mix narration over ducked music, to one audio track:
ffmpeg -i vo.wav -i music.mp3 -filter_complex \
  "[1:a]volume=0.25[m];[0:a][m]amix=inputs=2:duration=first:dropout_transition=0[a]" \
  -map "[a]" mix.wav

# 2) Loudness-normalize the mixed audio to -16 LUFS:
ffmpeg -i mix.wav -af loudnorm=I=-16:TP=-1.5:LRA=11 mix_norm.wav

# 3) Mux the normalized audio onto the assembled video (video copied, audio encoded):
ffmpeg -i sequence.mp4 -i mix_norm.wav -map 0:v:0 -map 1:a:0 \
  -c:v copy -c:a aac -shortest final.mp4
```

> When you mix more than one audio source in one filtergraph, **split streams explicitly and
> never reuse a stream label** — a reused label is rejected by portable ffmpeg. Mix without
> auto-normalization (`amix ... normalize=0` where you need the balance preserved), then verify
> loudness. (This bites hard on the cloud image — see plan 05.)

- **Optional RTL Hebrew caption burn** (only if wanted, on top of the code caption layers).
  Because Hebrew is right-to-left, burn it, then **look at a frame and confirm it rendered
  correctly** — never assume:

```
ffmpeg -i final.mp4 -vf "subtitles=caption.srt" -c:a copy final_captioned.mp4
```

- **Gate 4: watch the preview end-to-end, show total spend, wait for approval**, then keep the
  final file in the run folder.

## Full-trial cost (from the engine contract)

One 8s `veo-lite` world clip @720p ($0.05 × 8 = $0.40) + one short narration (~$0.01) + one music
clip ($0.04) = **~$0.45**. Statement and wordmark beats are **code layers ($0)**. Add **$0.067**
if a world beat is keyframe-anchored on a generated organic still (Path A's identity render is
that still). The vertical format does not change this — video pricing is per second. With `omni`
instead of `veo-lite`, the world clip is ~$0.80–1.00. The prep-loaded credit (~$15) covers dozens
of runs.

## What the student ends up with, and where next

A real, finished, on-brand vertical **sequence** produced entirely through their own engine —
having seen the world clip, narration, music, and code brand layers come together, and having
approved each gate. From here the production agent (plan 02) grows this into richer sequences —
more world beats, statement beats, variations — and finally plan 04 wraps it in the Telegram bot
so it runs from the phone, and plan 05 deploys that bot to the cloud so it runs with the PC off.
