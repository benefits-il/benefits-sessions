INTERNAL OPERATIONS MEMO — Print Vendor Contract Renewal

To: Operations and Finance
From: Tamar, People and Ops
Re: Annual renewal of the large-format printer service contract

This is the routine annual note about the service contract for the large-format printer we use for client proofs and mockups. The contract with the current vendor expires at the end of next month, and we need to decide whether to renew or switch.

What the contract covers:
- On-site maintenance within two business days for any fault.
- Replacement toner and large-format ink, shipped on request.
- One preventive service visit per quarter.
- The annual fee is unchanged from last year. The vendor sent the renewal quote and it matches the previous one.

Two things to decide before the deadline:
- Whether to keep the same service tier or downgrade to the cheaper tier, given that we print fewer physical proofs than we did two years ago and send more for digital approval.
- Whether to ask for a second quote from the alternative vendor that contacted us in the spring, just to compare, even if we end up staying.

Finance, please confirm the budget line is approved before the 25th so we do not lapse and lose the two-day response window. If we let it lapse, faults get handled on a best-effort basis only, which already cost us a delayed proof last year.

This is an operational housekeeping item. No action needed from the design or copy teams.
