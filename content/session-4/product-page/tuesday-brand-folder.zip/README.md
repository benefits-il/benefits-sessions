# Tuesday — brand folder (for the hero-video exercise)

This is a ready-made brand you can use for the home exercise, so you don't have to invent your own.

**Tuesday** is a (made-up) company: work management for the one-person company — the anti-Monday.

## How to use this folder

1. Open this folder in **Claude Code** (in VS Code).
2. Paste the **cover-image prompt** from the lesson page. Claude reads the brand files here and writes you a ready image prompt.
3. Copy that image prompt into **Gemini** or **ChatGPT**, and attach `logo.png` (below) as the reference image.
4. Continue with the lesson: download the image, take it into **Google Flow**, and paste the **animate prompt**.

## What's in here

- `brand-sheet.md` — the brand bones: colors, logo, voice, taglines.
- `product-one-pager.md` — what Tuesday is and who it's for.
- `logo.png` — the Tuesday mark (the yellow Tiwaz rune). This is your reference image.
