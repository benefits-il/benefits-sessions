# ערכת משימת-הסיום — פרויקט NotebookLM עם התנור

הערכה הזאת היא למשימת-הסיום של יחידת STUDIO (5.6). מבצעים אותה בשני שלבים.

## שני השלבים

**שלב א — ריצה אחת.** בוחרים רעיון אחד מתוך החמישה שבקובץ projects.md — חידון, מסלול-טיול, כרטיסיות, טבלת-השוואה או מפת-ידע. מדביקים את הפרומפט שלו בקלוד, וקלוד בונה הכל בבת-אחת דרך החיבור של NotebookLM. רואים עד לאן ריצה אחת מגיעה.

**שלב ב — אותו דבר, בשיטת התנור.** חוזרים לחמשת הרעיונות, לוקחים את מה שכבר בניתם או בוחרים רעיון אחר, ומריצים אותו הפעם כפרויקט מנוהל-תנור. ההבדל בין ריצה אחת למערכת מנוהלת הוא כל מה שהיחידה הזאת מלמדת.

## איך מריצים את שלב ב

1. פותחים תיקייה חדשה וריקה.
2. מעתיקים אליה את הקובץ oven.md מהערכה. (דוברי אנגלית: לוקחים את oven.en.md ומשנים את שמו ל-oven.md.)
3. פותחים את התיקייה בקלוד קוד.
4. מדביקים את פרומפט-הרעיון שבחרתם מתוך projects.md.
5. מוסיפים בסוף את המשפט שמפעיל את התנור:

```
אני רוצה לבנות את הפרויקט הזה בשיטת התנור — קרא קודם את oven.md שבתיקייה.
```

מכאן קלוד כבר לא רץ בבת-אחת: הוא קורא את התנור, אומר לכם איפה אתם עומדים, ומוביל אתכם תחנה-תחנה.

---

# Final-Project Kit — a NotebookLM project with the oven

This kit is for the final project of the STUDIO unit (5.6). You do it in two stages.

## The two stages

**Stage A — a single run.** Pick one idea out of the five in projects.md — a quiz, a trip route, flashcards, a comparison table, or a knowledge map. Paste its prompt into Claude, and Claude builds the whole thing in one go through the NotebookLM connection. See how far a single run gets you.

**Stage B — the same thing, with the oven method.** Go back to the five ideas, take what you already built or pick a different idea, and this time run it as an oven-managed project. The difference between a single run and a managed system is everything this unit teaches.

## How to run stage B

1. Open a new, empty folder.
2. Copy the file oven.en.md from the kit into it and rename it to oven.md.
3. Open the folder in Claude Code.
4. Paste the prompt of the idea you chose from projects.md.
5. Add at the end the sentence that turns on the oven:

```
I want to build this project with the oven method — read oven.md in the folder first.
```

From here Claude no longer runs all at once: it reads the oven, tells you where you stand, and leads you station by station.
